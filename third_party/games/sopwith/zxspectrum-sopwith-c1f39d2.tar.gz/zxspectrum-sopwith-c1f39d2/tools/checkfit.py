#!/usr/bin/env python3
#
# Copyright (C) 2026 Neil Rackett
# SPDX-License-Identifier: GPL-3.0-or-later
#
"""Check the build still fits, and say where the memory went.

The whole design answers one inequality: the end of the variables has to come
below the stack, which has to come below the back buffer. Nothing in the
toolchain enforces it. The link succeeds either way and the game corrupts its
own object pool with return addresses, which looks nothing like a memory
problem when it finally shows itself.

So this runs on every build. The back buffer's address is read out of gfx.asm
rather than repeated here, because that is where it is decided.

Usage: checkfit.py <map file> <gfx.asm> <stack pointer>
"""

import re
import sys


def symbol(text, name):
    m = re.search(r"^%s\s+=\s+\$([0-9A-F]+)" % name, text, re.M)
    if m is None:
        raise SystemExit("checkfit: no %s in the map file" % name)
    return int(m.group(1), 16)


def main(argv):
    if len(argv) != 4:
        raise SystemExit(f"usage: {argv[0]} <map> <gfx.asm> <stack pointer>")

    mapfile = open(argv[1]).read()
    asm = open(argv[2]).read()
    sp = int(argv[3], 0)

    m = re.search(r"^defc\s+BUF\s*=\s*\$([0-9A-F]+)", asm, re.M)
    if m is None:
        raise SystemExit("checkfit: no BUF in %s" % argv[2])
    buf = int(m.group(1), 16)

    code = symbol(mapfile, "__CODE_head")
    data = symbol(mapfile, "__DATA_head")
    bss = symbol(mapfile, "__BSS_head")
    end = symbol(mapfile, "__BSS_END_tail")

    # z88dk puts read-only data in with the code, so the sprites, the
    # compressed terrain and the level table are all in the first figure
    print("  code      $%04X  %6d bytes, constants included" % (code, data - code))
    print("  data      $%04X  %6d bytes" % (data, bss - data))
    print("  variables $%04X  %6d bytes" % (bss, end - bss))
    print("  ---")
    print("  stack     $%04X  %6d bytes free below it" % (sp, sp - end))
    print("  buffer    $%04X  %6d bytes" % (buf, 6144))

    if end >= sp:
        raise SystemExit(
            "\ncheckfit: variables reach $%04X, past the stack at $%04X.\n"
            "The link succeeded but the game would overwrite its own data.\n"
            "Reduce MAX_OBJS in src/sopwith.h, or move the buffer up if there\n"
            "is anywhere left to move it to." % (end, sp))

    if sp > buf:
        raise SystemExit(
            "\ncheckfit: the stack at $%04X is inside the back buffer at "
            "$%04X." % (sp, buf))

    # The deepest call chain measures a little under 300 bytes, most of it
    # adjustbullet's two object copies, and the ROM interrupt lands on top.
    if sp - end < 400:
        print("\ncheckfit: warning - only %d bytes of stack. The deepest call\n"
              "chain needs close to 300, so this is thinner than it looks."
              % (sp - end))


if __name__ == "__main__":
    main(sys.argv)
