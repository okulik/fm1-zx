#!/usr/bin/env python3
#
# Copyright (C) 2026 Neil Rackett
# SPDX-License-Identifier: GPL-3.0-or-later
#
"""Turn a binary file into a C array header, so it can be linked into the code.

Usage: bin2c.py <input> <output.h> <symbol>
"""

import os
import sys

PER_LINE = 12


def main(argv):
    if len(argv) != 4:
        raise SystemExit(f"usage: {argv[0]} <input> <output.h> <symbol>")

    src, dst, symbol = argv[1], argv[2], argv[3]
    data = open(src, "rb").read()
    guard = f"{symbol.upper()}_H"

    with open(dst, "w") as out:
        out.write("/*\n")
        out.write(" * Copyright (C) 2026 Neil Rackett\n")
        out.write(" * SPDX-License-Identifier: GPL-3.0-or-later\n")
        out.write(" */\n\n")
        out.write(f"/* Generated from {os.path.basename(src)} by bin2c.py. Do not edit. */\n\n")
        out.write(f"#ifndef {guard}\n#define {guard}\n\n")
        out.write(f"#define {symbol}_len {len(data)}\n\n")
        out.write(f"static const unsigned char {symbol}[] = {{\n")

        for i in range(0, len(data), PER_LINE):
            chunk = ", ".join(f"0x{b:02X}" for b in data[i : i + PER_LINE])
            out.write(f"    {chunk},\n")

        out.write("};\n\n")
        out.write(f"#endif\n")

    print(f"  {dst}: {len(data)} bytes as {symbol}[]")


if __name__ == "__main__":
    main(sys.argv)
