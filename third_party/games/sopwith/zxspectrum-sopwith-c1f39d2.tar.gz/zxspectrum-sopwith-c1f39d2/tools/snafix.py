#!/usr/bin/env python3
#
# Copyright (C) 2026 Neil Rackett
# SPDX-License-Identifier: GPL-3.0-or-later
#
"""Move a .sna snapshot's stack out of the program's own code.

A .sna has nowhere to record the program counter, so it is pushed onto the
stack and the loader pops it. appmake picks the stack for us, and picks it a
few hundred bytes above the load address - which for a program loading at
$5CD0 is inside its own code. Two bytes are overwritten by the pushed PC, and
the startup code then pushes IY and HL before it relocates the stack, taking
out two more.

That is four bytes of the arithmetic library gone, and it goes wrong nowhere
near where it happened: the game loads, draws, flies, and resets the first
time it multiplies. The tape build is fine, because BASIC leaves the stack
high, so the two disagree and only the snapshot is broken.

--sna-sp is meant to control this and does not, so the header is rewritten
here instead: the pushed PC goes somewhere harmless, the header points at it,
and the bytes appmake trampled are restored from the linked binary.

Usage: snafix.py <sna> <code binary> <org> <stack>
"""

import sys

HEADER = 27
RAM = 0x4000
SP_FIELD = 23


def main(argv):
    if len(argv) != 5:
        raise SystemExit(f"usage: {argv[0]} <sna> <code bin> <org> <stack>")

    path, codepath = argv[1], argv[2]
    org, stack = int(argv[3], 0), int(argv[4], 0)

    sna = bytearray(open(path, "rb").read())
    code = open(codepath, "rb").read()

    def peek(a):
        return sna[HEADER + a - RAM]

    def poke(a, v):
        sna[HEADER + a - RAM] = v

    old_sp = sna[SP_FIELD] | (sna[SP_FIELD + 1] << 8)
    pc = peek(old_sp) | (peek(old_sp + 1) << 8)

    if pc != org:
        raise SystemExit("snafix: PC at the stack is $%04X, expected the load "
                         "address $%04X - has appmake changed?" % (pc, org))

    # Put the PC where the loader will find it, two below the stack the
    # startup is about to install, so the pops and pushes stay clear of
    # everything the linker placed.
    new_sp = stack - 2
    if new_sp <= org + len(code):
        raise SystemExit("snafix: $%04X is not above the program" % new_sp)

    # Give back what appmake overwrote
    for i in (0, 1):
        a = old_sp + i
        if org <= a < org + len(code):
            poke(a, code[a - org])

    poke(new_sp, pc & 0xFF)
    poke(new_sp + 1, pc >> 8)
    sna[SP_FIELD] = new_sp & 0xFF
    sna[SP_FIELD + 1] = new_sp >> 8

    open(path, "wb").write(bytes(sna))
    print("  %s: stack moved $%04X -> $%04X, %d bytes of code restored"
          % (path, old_sp, new_sp, sum(1 for i in (0, 1)
                                       if org <= old_sp + i < org + len(code))))


if __name__ == "__main__":
    main(sys.argv)
