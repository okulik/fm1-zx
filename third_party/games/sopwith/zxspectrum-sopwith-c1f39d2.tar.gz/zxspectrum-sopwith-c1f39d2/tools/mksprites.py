#!/usr/bin/env python3
#
# Copyright (C) 2026 Neil Rackett
# SPDX-License-Identifier: GPL-3.0-or-later
#
"""Turn src/sprites.txt into packed 1bpp Spectrum sprite data.

The original generates every rotation and mirror of each sprite at runtime,
into one byte per pixel.  Neither is affordable on a 48K Spectrum, so both
happen here instead: the rotations the game actually asks for are baked out
at build time, packed to one bit per pixel, and the frames are laid out in
the order the game indexes them so that lookup is a shift and an add.

Every sprite is stored two bytes per row, left aligned, whatever its width.
That wastes a byte a row on the 8-wide debris and bombs, about 200 bytes in
all, and in exchange the blitter has one shape to draw and no width test.

Usage: mksprites.py <sprites.txt> <output.h>
"""

import os
import sys


def read_sprites(path):
    """Parse the sprite text file into {name: (w, h, [rows of '#'/'.'])}."""
    sprites = {}
    name = None
    w = h = 0
    rows = []

    for lineno, line in enumerate(open(path), 1):
        line = line.rstrip("\n")
        # Comments start with a semicolon, not a hash: a hash is a set pixel,
        # and plenty of rows begin with one
        if line.startswith(";") or line.strip() == "":
            continue
        if line.startswith("sprite "):
            if name is not None:
                sprites[name] = (w, h, rows)
            _, name, ws, hs = line.split()
            w, h, rows = int(ws), int(hs), []
            continue
        if name is None:
            raise SystemExit(f"{path}:{lineno}: pixels before any sprite header")
        rows.append(line)

    if name is not None:
        sprites[name] = (w, h, rows)

    for name, (w, h, rows) in sprites.items():
        if len(rows) != h:
            raise SystemExit(f"{name}: declared {h} rows, found {len(rows)}")
        for r in rows:
            if len(r) != w:
                raise SystemExit(f"{name}: declared {w} wide, found {len(r)}")

    return sprites


def rotate(sprite, rotations, mirror):
    """Rotate a quarter turn at a time, then optionally flip vertically.

    This mirrors Rotate() in swsymbol.c exactly, so the frames come out in the
    same orientation the original picks for each angle.
    """
    w, h, rows = sprite
    pix = {(x, y) for y in range(h) for x in range(w) if rows[y][x] == "#"}

    for _ in range(rotations):
        pix = {(y, w - 1 - x) for (x, y) in pix}
        w, h = h, w

    if mirror:
        pix = {(x, h - 1 - y) for (x, y) in pix}

    out = ["".join("#" if (x, y) in pix else "." for x in range(w))
           for y in range(h)]
    return w, h, out


def pack(sprite):
    """Pack to two bytes per row, most significant bit leftmost."""
    w, h, rows = sprite
    if w > 16:
        raise SystemExit(f"sprite is {w} pixels wide; 16 is the limit")
    data = []
    for y in range(h):
        bits = 0
        for x in range(w):
            if rows[y][x] == "#":
                bits |= 0x8000 >> x
        data.append((bits >> 8) & 0xFF)
        data.append(bits & 0xFF)
    return data


# Which frames the game asks for, in the order it indexes them.  Each entry is
# (C name, [(source sprite, rotations, mirror), ...]).
#
# Planes come first and are indexed [orient * 16 + angle], flattening the
# original's symbol_plane[angle % 4].sym[angle / 4] lookup and its mirrored
# equivalent for a plane flying upside down.
PLANE_FRAMES = ([("plane%d" % (a % 4), a // 4, False) for a in range(16)]
                + [("plane%d" % (((16 - a) % 16) % 4), ((16 - a) % 16) // 4, True)
                   for a in range(16)])

MANIFEST = [
    ("spr_plane", PLANE_FRAMES),
    # A plane going straight down, one frame per orient value; the original
    # increments orient while falling, so all four are reachable.
    ("spr_planehit", [("planehit%d" % i, 0, False) for i in range(4)]),
    # Flying into the sun, four frames of the closing animation.
    ("spr_planewin", [("planewin%d" % i, 0, False) for i in range(4)]),
    # Bombs are symbol_bomb[angle % 2].sym[angle / 2] over eight angles.
    ("spr_bomb", [("bomb%d" % (a % 2), a // 2, False) for a in range(8)]),
    # The four building types the original map uses, each unmirrored then
    # mirrored, so a target frame is [type * 2 + mirrored].
    #
    # "Mirrored" is the original's TRANSFORM_MIRROR, which is symbol index 6:
    # rotate 180 and then flip vertically, which composes to a flip about the
    # vertical axis. Asking for the flip alone gives index 4 and turns the
    # building upside down - it still reads as a building, so it is easy to
    # miss, but it leaves the sprite's solid half at the top of the cell and
    # collision follows the pixels.
    ("spr_target", sum([[("target%d" % t, 0, False), ("target%d" % t, 2, True)]
                        for t in range(4)], [])),
    ("spr_targhit", [("targhit0", 0, False), ("targhit0", 2, True)]),
    ("spr_debris", [("debris%d" % i, 0, False) for i in range(8)]),
    ("spr_flock", [("flock%d" % i, 0, False) for i in range(2)]),
    ("spr_bird", [("bird%d" % i, 0, False) for i in range(2)]),
    ("spr_ox", [("ox%d" % i, 0, False) for i in range(2)]),
]


def main(argv):
    if len(argv) != 3:
        raise SystemExit(f"usage: {argv[0]} <sprites.txt> <output.h>")

    src, dst = argv[1], argv[2]
    sprites = read_sprites(src)

    blobs = []       # (label, [bytes])
    tables = []      # (C name, [(label, w, h)])
    seen = {}        # packed data -> label, so identical frames share bytes
    total = 0

    for cname, frames in MANIFEST:
        entries = []
        for base, rot, mirror in frames:
            if base not in sprites:
                raise SystemExit(f"{src}: no sprite named '{base}'")
            w, h, rows = rotate(sprites[base], rot, mirror)
            data = pack((w, h, rows))
            key = bytes(data)
            label = seen.get(key)
            if label is None:
                label = "sd_%d" % len(blobs)
                seen[key] = label
                blobs.append((label, data))
                total += len(data)
            entries.append((label, w, h))
        tables.append((cname, entries))

    with open(dst, "w") as out:
        out.write("/*\n")
        out.write(" * Copyright (C) 2026 Neil Rackett\n")
        out.write(" * SPDX-License-Identifier: GPL-3.0-or-later\n")
        out.write(" */\n\n")
        out.write("/* Generated from %s by mksprites.py. Do not edit. */\n\n"
                  % os.path.basename(src))
        out.write("#ifndef SPRITES_H\n#define SPRITES_H\n\n")

        for label, data in blobs:
            body = ", ".join("0x%02X" % b for b in data)
            out.write("static const unsigned char %s[] = {%s};\n" % (label, body))

        out.write("\n")

        for cname, entries in tables:
            out.write("const sprite_t %s[%d] = {\n" % (cname, len(entries)))
            for label, w, h in entries:
                out.write("    {%d, %d, %s},\n" % (w, h, label))
            out.write("};\n\n")

        out.write("#endif\n")

    print("  %s: %d frames, %d bytes of pixel data"
          % (dst, sum(len(e) for _, e in tables), total))


if __name__ == "__main__":
    main(sys.argv)
