#!/usr/bin/env python3
#
# Copyright (C) 2026 Neil Rackett
# SPDX-License-Identifier: GPL-3.0-or-later
#
"""Turn src/ground.txt into a raw height array, ready for zx0 compression.

The map is one byte per world pixel column, 3000 of them, and the game needs
it in RAM because bomb craters rewrite it.  Three kilobytes of literal C array
would be three kilobytes of binary; the profile is smooth enough that zx0 gets
it under a fifth of that, so the Makefile compresses this output and the game
unpacks it into its working copy when a level starts.

Heights are clamped to the Spectrum's shorter play area on the way through.

Usage: mkground.py <ground.txt> <output.bin>
"""

import sys

# The play area is 192 pixels tall and the tallest sprite is 16, so a wall
# this high is one no plane can climb over: the same role the PC version's
# 199 plays in its 200-pixel screen.
MAX_HEIGHT = 190


def main(argv):
    if len(argv) != 3:
        raise SystemExit(f"usage: {argv[0]} <ground.txt> <output.bin>")

    src, dst = argv[1], argv[2]

    heights = []
    for line in open(src):
        if line.startswith("#"):
            continue
        heights.extend(int(v) for v in line.split())

    clamped = sum(1 for h in heights if h > MAX_HEIGHT)
    data = bytes(min(h, MAX_HEIGHT) for h in heights)

    open(dst, "wb").write(data)
    print("  %s: %d columns, %d clamped to %d"
          % (dst, len(data), clamped, MAX_HEIGHT))


if __name__ == "__main__":
    main(sys.argv)
