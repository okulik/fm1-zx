/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * ZX Sopwith - the map
 *
 * The original Sopwith map, three thousand pixels of it, kept exactly as the
 * PC version has it. Custom missions are gone: they need a file system to
 * load from and a parser to read them with, and neither fits.
 *
 * The ground profile is one byte per world column and has to be in RAM
 * because bombs crater it, so three kilobytes are unavoidable at run time.
 * Three kilobytes of literal array in the binary as well is not, and the
 * profile is smooth enough that zx0 takes it under a fifth of that, so it
 * ships compressed and is unpacked when a level starts.
 */

#include <compress.h>

#include "sopwith.h"
#include "ground_zx0.h"

uint8_t ground[WORLD_W];

/*
 * Factions collapse from the original's eight to two. Everything the PC
 * version calls player 2, 3 or 4 defends the same side against you here,
 * because without network play there is only ever one human in the air.
 */
const orig_ob_t level_objects[] = {
    /* Left of the map */
    {TARGET,  1, 191,    0,    0, FACTION_ENEMY,  0},
    {TARGET,  3, 284,    0,    0, FACTION_ENEMY,  0},
    {FLOCK,   0, 370,  370, 2630, FACTION_NONE,   0},
    {TARGET,  1, 409,    0,    0, FACTION_ENEMY,  0},
    {TARGET,  1, 539,    0,    0, FACTION_ENEMY,  0},
    {PLANE,   0, 588,    0, 1154, FACTION_ENEMY,  0},
    {TARGET,  3, 685,    0,    0, FACTION_ENEMY,  1},
    {TARGET,  0, 807,    0,    0, FACTION_ENEMY,  0},
    {TARGET,  1, 934,    0,    0, FACTION_ENEMY,  0},

    /* Your base */
    {FLOCK,   0, 1000, 370, 2630, FACTION_NONE,   0},
    {TARGET,  2, 1210,   0,    0, FACTION_PLAYER, 0},
    {TARGET,  0, 1240,   0,    0, FACTION_PLAYER, 0},
    {PLANE,   0, 1270, 901, 1835, FACTION_PLAYER, 0},
    {OX,      0, 1376,   0,    0, FACTION_NONE,   0},
    {TARGET,  3, 1440,   0,    0, FACTION_PLAYER, 0},

    /* Theirs */
    {TARGET,  3, 1550,   0,    0, FACTION_ENEMY,  1},
    {OX,      0, 1608,   0,    0, FACTION_NONE,   0},
    {FLOCK,   0, 1630, 370, 2630, FACTION_NONE,   0},
    {PLANE,   1, 1720, 1155, 2089, FACTION_ENEMY, 0},
    {TARGET,  0, 1750,   0,    0, FACTION_ENEMY,  0},
    {TARGET,  2, 1780,   0,    0, FACTION_ENEMY,  0},
    {TARGET,  1, 2024,   0,    0, FACTION_ENEMY,  0},

    /* Right of the map */
    {TARGET,  1, 2159,   0,    0, FACTION_ENEMY,  0},
    {TARGET,  3, 2279,   0,    0, FACTION_ENEMY,  1},
    {TARGET,  3, 2390,   0,    0, FACTION_ENEMY,  0},
    {PLANE,   1, 2456, 2089, 9999, FACTION_ENEMY, 0},
    {TARGET,  0, 2549,   0,    0, FACTION_ENEMY,  0},
    {FLOCK,   0, 2630, 370, 2630, FACTION_NONE,   0},
    {TARGET,  0, 2678,   0,    0, FACTION_ENEMY,  0},
    {TARGET,  1, 2763,   0,    0, FACTION_ENEMY,  0},
};

const uint8_t level_num_objects =
    sizeof(level_objects) / sizeof(level_objects[0]);

void initgrnd(void)
{
    dzx0_standard((void *)ground_zx0, ground);
}
