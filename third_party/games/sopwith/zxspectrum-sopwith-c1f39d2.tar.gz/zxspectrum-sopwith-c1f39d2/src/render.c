/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * ZX Sopwith - putting a frame on the screen
 *
 * World Y counts up from the bottom of the screen, so a screen row is
 * SCR_H - 1 - y and a sprite is drawn downwards from its top edge, which is
 * where the original keeps an object's Y.
 *
 * Colour is a whole 8x8 cell at a time on this machine, and the play field
 * scrolls, so there is nowhere sensible to put a colour boundary: the play
 * area is one ink throughout and the status bar another. Nothing can clash,
 * and the attribute file is written once at the start of a level instead of
 * every frame.
 */

#include "sopwith.h"
#include "gfx.h"
#include "render.h"

/* Attribute byte: FLASH(7) BRIGHT(6) PAPER(5-3) INK(2-0). Paper is black
   throughout, so these are all just a choice of ink. */
#define ATTR_BASE   ((uint8_t *)0x5800)
#define ATTR_PLAY   0x47                /* bright white, the play field     */
#define ATTR_STATUS 0x45                /* bright cyan, the instruments     */
#define ATTR_TITLE  0x46                /* bright yellow, the name and menu */

/* Character rows the play field owns; the status bar has the other three */
#define ATTR_PLAY_ROWS (24 - 3)
#define ATTR_KEYS   0x45                /* bright cyan, the control list    */
#define ATTR_CREDIT 0x07                /* plain white reads as grey        */

/* The status bar occupies the bottom three character rows */
#define ST_ROW0     21
#define ST_ROW1     22
#define ST_ROW2     23
#define ST_SEP      (SCR_H - STATUS_H)  /* the rule above it, row 168 */

/*
 * The minimap. The whole three thousand pixel map is squeezed into 93 columns
 * on the right of the status bar, one column per 32 world pixels and one row
 * per 16.
 *
 * Both scales are powers of two on purpose. The obvious 27 and 13 fit the
 * space more exactly, but they turn every column of the rebuild and every
 * plane marker into a call to sdcc's divide, which costs the better part of a
 * thousand cycles; as shifts the whole map is nearly free.
 *
 * It is redrawn into a small bitmap only when a building falls, and blitted
 * from there each frame, so the usual per-frame cost is 144 bytes moved
 * rather than three thousand height samples scanned. Bomb craters are a
 * pixel or two deep, which at a sixteenth scale cannot show, so they do not
 * trigger a rebuild.
 */
#define MAP_COL     20                  /* character column it starts at */
#define MAP_COLS    93
#define MAP_BYTES   12
#define MAP_ROWS    12
#define MAP_TOP     172                 /* screen row of the bitmap's top */
#define MAP_XSHIFT  5                   /* 32 world pixels per column */
#define MAP_YSHIFT  4                   /* 16 world pixels per row */

static uint8_t  minimap[MAP_ROWS * MAP_BYTES];
static bool_t   minimap_dirty;
static uint16_t lastoffset;

void minimap_invalidate(void)
{
    minimap_dirty = TRUE;
}

static void map_plot(uint8_t mx, uint8_t my)
{
    if (mx >= MAP_COLS || my >= MAP_ROWS) {
        return;
    }
    minimap[my * MAP_BYTES + (mx >> 3)] |= 0x80 >> (mx & 7);
}

static void minimap_rebuild(void)
{
    const uint8_t *g = ground;
    uint8_t col, i, h, maxh, prev;

    for (i = 0; i < MAP_ROWS * MAP_BYTES; i++) {
        minimap[i] = 0;
    }

    prev = 0;
    for (col = 0; col < MAP_COLS; col++) {
        maxh = 0;
        /* Walked by pointer: indexing this by a 16 bit x costs three times as
           much, and there are three thousand of them */
        for (i = 0; i < (1 << MAP_XSHIFT); i++) {
            if (*g > maxh) {
                maxh = *g;
            }
            g++;
        }

        h = maxh >> MAP_YSHIFT;
        if (h >= MAP_ROWS) {
            h = MAP_ROWS - 1;
        }

        /* Join up to the previous column so the profile reads as a line */
        if (col == 0 || h == prev) {
            map_plot(col, MAP_ROWS - 1 - h);
        } else if (h > prev) {
            for (i = prev + 1; i <= h; i++) {
                map_plot(col, MAP_ROWS - 1 - i);
            }
        } else {
            for (i = h; i < prev; i++) {
                map_plot(col, MAP_ROWS - 1 - i);
            }
        }
        prev = h;
    }

    /* Standing buildings, so you can see what is left to flatten */
    {
        obj_t *ob;
        for (ob = objtop; ob != NULL; ob = ob->next) {
            if (ob->type != TARGET || !(ob->flags & OF_ONMAP)) {
                continue;
            }
            map_plot((uint8_t)(ob->x >> MAP_XSHIFT),
                     (uint8_t)(MAP_ROWS - 1 - (ob->y >> MAP_YSHIFT)));
        }
    }

    minimap_dirty = FALSE;
}

/* --- text ------------------------------------------------------------- */

void puttext(uint8_t cx, uint8_t cy, const char *s)
{
    gfx_text(cx, cy, s);
}

/*
 * Right aligned, space padded, and without a single division: sdcc's divide
 * costs the better part of a thousand cycles, and the status bar wants five
 * numbers a frame. Subtracting each power of ten in turn is at worst nine
 * subtractions per digit and needs no library call at all.
 */
void putnum(uint8_t cx, uint8_t cy, int16_t v, uint8_t width)
{
    static const int16_t pow10[5] = { 10000, 1000, 100, 10, 1 };
    char digits[7];
    char buf[13];
    uint8_t n = 0, d = 0, p;
    bool_t started = FALSE;

    if (v < 0) {
        digits[d++] = '-';
        v = -v;
    }

    for (p = 0; p < 5; p++) {
        int16_t unit = pow10[p];
        uint8_t digit = 0;

        while (v >= unit) {
            v -= unit;
            digit++;
        }
        if (digit != 0 || started || p == 4) {
            digits[d++] = (char)('0' + digit);
            started = TRUE;
        }
    }

    /* Padded and assembled first, so the whole field is one call */
    while (width > d) {
        buf[n++] = ' ';
        width--;
    }
    for (p = 0; p < d; p++) {
        buf[n++] = digits[p];
    }
    buf[n] = '\0';

    gfx_text(cx, cy, buf);
}

/* --- status bar ------------------------------------------------------- */

static void dispstatus(void)
{
    obj_t *ob = consoleplayer;
    uint8_t i;

    /*
     * No need to blank the bar first: the whole buffer was cleared at the top
     * of the frame, and the ground stops a row above this rule, which doubles
     * as the horizon.
     */
    gfx_hline(ST_SEP - 1);

    puttext(0, ST_ROW0, "SCORE");
    putnum(9, ST_ROW0, score, 6);

    puttext(0, ST_ROW1, "FUEL");
    putnum(5, ST_ROW1, ob->life / 90, 3);
    puttext(9, ST_ROW1, "GUN");
    putnum(13, ST_ROW1, ob->rounds, 3);

    puttext(0, ST_ROW2, "BOMBS");
    putnum(6, ST_ROW2, ob->bombs, 1);
    puttext(9, ST_ROW2, "LIVES");
    putnum(15, ST_ROW2, MAXCRASH - ob->crashcnt, 1);

    if (minimap_dirty) {
        minimap_rebuild();
    }
    gfx_blitmap(minimap, MAP_TOP, MAP_ROWS, MAP_COL, MAP_BYTES);

    /* Planes move, so they go on top of the cached map every frame */
    for (i = 0; i < num_planes; i++) {
        obj_t *p = planes[i];

        if (p == NULL || !(p->flags & OF_ONMAP) || p->state == FINISHED) {
            continue;
        }
        gfx_pixel(MAP_COL * 8 + (p->x >> MAP_XSHIFT),
                  MAP_TOP + MAP_ROWS - 1 - (p->y >> MAP_YSHIFT));
    }
}

/*
 * Coloured blocks are collected while the frame is drawn and painted
 * afterwards, a row at a time, so that no cell is ever written twice. See
 * attr_paint below for why that matters.
 */
#define MAX_ARECTS 12

static uint8_t  arect[MAX_ARECTS][5];   /* x0, y0, x1, y1, attribute */
static uint8_t  narects;

/*
 * Which rows hold colour, this frame and last. A bitmask would be tidier but
 * twenty one rows needs a long, and a shift by a variable is a library call
 * on this compiler - dear in cycles and dearer in the bytes there is no room
 * for. A flag per row costs 42 bytes of memory and nothing else.
 */
static uint8_t  arows[ATTR_PLAY_ROWS], arows_last[ATTR_PLAY_ROWS];

/*
 * Note the cells an object covers. Sprites are not character aligned, so a 16
 * pixel sprite reaches into three columns as often as two, and the block has
 * to cover wherever it actually landed.
 */
static void attr_object(int16_t sx, int16_t sy, const sprite_t *sym, uint8_t a)
{
    int16_t x0 = sx >> 3;
    int16_t x1 = (sx + sym->w - 1) >> 3;
    int16_t y0 = sy >> 3;
    int16_t y1 = (sy + sym->h - 1) >> 3;
    uint8_t y;

    x0 = clamp_min(x0, 0);
    y0 = clamp_min(y0, 0);
    x1 = clamp_max(x1, 31);
    y1 = clamp_max(y1, ATTR_PLAY_ROWS - 1);

    if (x1 < x0 || y1 < y0 || narects >= MAX_ARECTS) {
        return;
    }

    arect[narects][0] = (uint8_t)x0;
    arect[narects][1] = (uint8_t)y0;
    arect[narects][2] = (uint8_t)x1;
    arect[narects][3] = (uint8_t)y1;
    arect[narects][4] = a;
    narects++;

    for (y = (uint8_t)y0; y <= (uint8_t)y1; y++) {
        arows[y] = 1;
    }
}

/*
 * Paint the attribute file. Only the rows holding colour now, or holding it
 * last frame and needing it taken away again, are touched at all - which is
 * usually five or six of the twenty one, the rest being open sky that has
 * been the background colour since the level started.
 *
 * Each row is prepared complete in a scratch buffer and then written once.
 * Writing the screen's own attributes twice - blank, then colour - is what
 * made this flicker: nothing double buffers the attribute file, so the ULA
 * reads it mid-repaint and catches the blank.
 */
static void attr_paint(void)
{
    static uint8_t row[32];
    uint8_t y, i, r;

    for (y = 0; y < ATTR_PLAY_ROWS; y++) {
        if (!arows[y] && !arows_last[y]) {
            continue;
        }

        for (i = 0; i < 32; i++) {
            row[i] = ATTR_PLAY;
        }
        for (r = 0; r < narects; r++) {
            if (y >= arect[r][1] && y <= arect[r][3]) {
                for (i = arect[r][0]; i <= arect[r][2]; i++) {
                    row[i] = arect[r][4];
                }
            }
        }
        gfx_attrrow(y, row);
        arows_last[y] = arows[y];
    }
}

/* --- the frame -------------------------------------------------------- */

/*
 * The status bar and the title screen colour by character row, which is all a
 * fixed layout needs. The play field cannot: it scrolls, so any boundary drawn
 * into it would have objects walking across it. Instead its attributes are
 * repainted with the background every frame and each plane and building then
 * stamps its own cells, so the two sides are told apart by colour.
 *
 * Whatever else falls in those cells takes the colour too - the ground under a
 * hangar, a bullet passing a wingtip. That is the Spectrum's bargain and it is
 * worth taking here, because without it there is no way at all to see whose
 * buildings you are bombing.
 */
static const uint8_t attr_play[24] = {
    ATTR_PLAY,   ATTR_PLAY,   ATTR_PLAY,   ATTR_PLAY,
    ATTR_PLAY,   ATTR_PLAY,   ATTR_PLAY,   ATTR_PLAY,
    ATTR_PLAY,   ATTR_PLAY,   ATTR_PLAY,   ATTR_PLAY,
    ATTR_PLAY,   ATTR_PLAY,   ATTR_PLAY,   ATTR_PLAY,
    ATTR_PLAY,   ATTR_PLAY,   ATTR_PLAY,   ATTR_PLAY,
    ATTR_PLAY,   ATTR_STATUS, ATTR_STATUS, ATTR_STATUS
};

static const uint8_t attr_title[24] = {
    ATTR_PLAY,   ATTR_TITLE,  ATTR_PLAY,   ATTR_PLAY,  /* name, then the
                                                          dogfight and rule */
    ATTR_PLAY,   ATTR_PLAY,   ATTR_KEYS,   ATTR_KEYS,
    ATTR_KEYS,   ATTR_KEYS,   ATTR_KEYS,   ATTR_KEYS,  /* the control list  */
    ATTR_TITLE,  ATTR_TITLE,  ATTR_TITLE,  ATTR_TITLE, /* what to press     */
    ATTR_PLAY,   ATTR_PLAY,   ATTR_CREDIT, ATTR_CREDIT,
    ATTR_CREDIT, ATTR_CREDIT, ATTR_CREDIT, ATTR_CREDIT /* the small print   */
};

static void setattr_rows(const uint8_t *rows)
{
    uint8_t *a = ATTR_BASE;
    uint8_t r, c;

    for (r = 0; r < 24; r++) {
        uint8_t v = rows[r];
        for (c = 0; c < 32; c++) {
            *a++ = v;
        }
    }
}

void setattrs(void)
{
    setattr_rows(attr_play);
}

void setattrs_title(void)
{
    setattr_rows(attr_title);
}

void initdisp(void)
{
    uint8_t i;

    minimap_invalidate();
    narects = 0;
    for (i = 0; i < ATTR_PLAY_ROWS; i++) {
        arows[i] = arows_last[i] = 0;
    }
    setattrs();
    lastoffset = 0;
    gfx_clear(0);
    gfx_show(0);
}

void swdisp(void)
{
    obj_t *ob;
    int16_t sx, sy;
    uint8_t toprow = 191;
    uint8_t i;
    uint16_t offset;

    /*
     * Only the previous frame left anything in the buffer, so only what it
     * touched has to be blanked.
     */
    gfx_clear(lastoffset);
    narects = 0;
    for (i = 0; i < ATTR_PLAY_ROWS; i++) {
        arows[i] = 0;
    }

    displx = clamp_range(0, consoleplayer->x - SCR_CENTR,
                         WORLD_W - SCR_W - 1);

    for (ob = objtop; ob != NULL; ob = ob->next) {
        if (!(ob->flags & OF_DRAW)) {
            continue;
        }

        sx = ob->x - displx;
        if (sx <= -16 || sx >= SCR_W) {
            continue;
        }

        sy = SCR_H - 1 - ob->y;
        if (sy >= SCR_H) {
            continue;
        }

        if (ob->sym == NULL) {
            gfx_pixel(sx, sy);
            if (sy >= 0 && sy < toprow) {
                toprow = (uint8_t)sy;
            }
        } else {
            gfx_sprite(sx, sy, ob->sym->data, ob->sym->h);
            if (sy < 0) {
                toprow = 0;
            } else if (sy < toprow) {
                toprow = (uint8_t)sy;
            }

            /* Only the things that belong to a side are worth colouring;
               bullets, debris and the animals stay the background colour */
            if (ob->type == TARGET || ob->type == PLANE) {
                attr_object(sx, sy, ob->sym,
                            ob->faction == FACTION_PLAYER
                                ? ATTR_MINE : ATTR_THEIRS);
            }
        }
    }

    gfx_ground(&ground[displx]);
    if ((191 - gnd_top) < toprow) {
        toprow = 191 - gnd_top;
    }

    attr_paint();
    dispstatus();

    if (consoleplayer->endsts != PLAYING) {
        puttext(12, 10, "THE END");
        toprow = 0;
    }

    /*
     * Only the thirds anything was drawn in need copying, and the topmost is
     * usually empty sky. Whatever the previous frame reached has to be copied
     * as well, or the erasing of it never gets to the screen.
     */
    offset = ((uint16_t)toprow >> 6) * GFX_THIRD;
    gfx_show(offset < lastoffset ? offset : lastoffset);
    lastoffset = offset;
}
