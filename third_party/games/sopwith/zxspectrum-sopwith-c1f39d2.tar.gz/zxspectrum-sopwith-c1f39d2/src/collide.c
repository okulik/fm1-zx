/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * ZX Sopwith - collisions, scoring and the end of a level
 *
 * A port of swcollsn.c and swend.c. The sweep is the original's: objects are
 * kept sorted by X, so each one only has to be tested against the neighbours
 * that start before its right hand edge, and the inner loop stops as soon as
 * it passes that. What differs is the pixel test underneath, which now works
 * on packed bits rather than a byte per pixel - a row of two sprites is one
 * shift and one AND instead of sixteen comparisons.
 */

#include "sopwith.h"
#include "render.h"

/* A bullet has no sprite; it is the top left pixel of this one */
static const uint8_t pixel_data[2] = { 0x80, 0x00 };

#define SYM_W(ob)    ((ob)->sym == NULL ? 1 : (ob)->sym->w)
#define SYM_H(ob)    ((ob)->sym == NULL ? 1 : (ob)->sym->h)
#define SYM_DATA(ob) ((ob)->sym == NULL ? pixel_data : (ob)->sym->data)

#define MAX_KILLS 16

static obj_t *killed[MAX_KILLS], *killer[MAX_KILLS];
static uint8_t killptr;

/*
 * Two planes that meet share the wreckage's momentum, so both sides of a
 * collision have something to record; one slot per plane, because more than
 * one pair can meet in a tic.
 */
static int16_t collsdx[MAX_PLANES], collsdy[MAX_PLANES];
static obj_t  *collsno[MAX_PLANES];
static uint8_t collptr;
static int16_t collxadj, collyadj;

static void tstcrash(obj_t *ob);

bool_t CollisionTest(obj_t *ob1, obj_t *ob2)
{
    const uint8_t *d1, *d2;
    int16_t x1, y1, x2, y2, w, h, y;
    uint16_t mask, r1, r2;

    if ((ob1->type == PLANE && ob1->state >= FINISHED)
     || (ob2->type == PLANE && ob2->state >= FINISHED)
     || (ob1->type == EXPLOSION && ob2->type == EXPLOSION)) {
        return FALSE;
    }

    if (ob1->x < ob2->x) {
        x1 = ob2->x - ob1->x;
        x2 = 0;
        w = clamp_max(SYM_W(ob1) - x1, SYM_W(ob2));
    } else {
        x1 = 0;
        x2 = ob1->x - ob2->x;
        w = clamp_max(SYM_W(ob2) - x2, SYM_W(ob1));
    }
    if (w <= 0) {
        return FALSE;
    }

    if (ob1->y < ob2->y) {
        y1 = 0;
        y2 = ob2->y - ob1->y;
        h = clamp_max(SYM_H(ob2) - y2, SYM_H(ob1));
    } else {
        y1 = ob1->y - ob2->y;
        y2 = 0;
        h = clamp_max(SYM_H(ob1) - y1, SYM_H(ob2));
    }
    if (h <= 0) {
        return FALSE;
    }

    d1 = SYM_DATA(ob1) + y1 * 2;
    d2 = SYM_DATA(ob2) + y2 * 2;
    mask = (uint16_t)(0xFFFFu << (16 - w));

    /* One of the two offsets is always zero, so only one row gets shifted */
    for (y = 0; y < h; y++) {
        r1 = ((uint16_t)d1[0] << 8) | d1[1];
        r2 = ((uint16_t)d2[0] << 8) | d2[1];
        if (x1) {
            r1 <<= x1;
        } else if (x2) {
            r2 <<= x2;
        }
        if (r1 & r2 & mask) {
            return TRUE;
        }
        d1 += 2;
        d2 += 2;
    }

    return FALSE;
}

/*
 * Everything you destroy scores, unless it was yours or it was an animal, in
 * which case it costs. The original works this out through a general "which
 * player gets the points" function; with one human pilot it is a test on the
 * faction of whatever just died.
 */
static void scoretarg(obj_t *ob, int16_t points)
{
    if (ob->faction == FACTION_PLAYER || ob->faction == FACTION_NONE) {
        score -= points;
    } else {
        score += points;
    }
}

static bool_t scorepenalty(uint8_t ttype, obj_t *ob, int16_t points)
{
    if (ttype == SHOT || ttype == BOMB
     || (ttype == PLANE
      && (ob->state == FLYING
       || (ob->state == FALLING && ob->hitcount == FALLCOUNT))
      && !(ob->flags & OF_ATHOME))) {
        scoretarg(ob, points);
        return TRUE;
    }
    return FALSE;
}

void scorepln(obj_t *ob)
{
    scoretarg(ob, 50);
}

void winner(obj_t *ob)
{
    ob->endsts = WINNER;
    ob->flags |= OF_GOINGSUN;
    ob->dx = ob->dy = 0;
    ob->state = FLYING;
    ob->life = MAXFUEL;
    ob->speed = MIN_SPEED;

    if (ob == consoleplayer) {
        endcount = 72;
    }
}

void loser(obj_t *ob)
{
    ob->endsts = LOSER;

    if (ob == consoleplayer) {
        endcount = 20;
    }
}

void endgame(uint8_t winning_faction)
{
    uint8_t i;

    for (i = 0; i < num_planes; i++) {
        obj_t *ob = planes[i];

        if (ob == NULL || ob->endsts != PLAYING) {
            continue;
        }
        if (ob->faction == winning_faction
         && (ob->crashcnt < (MAXCRASH - 1)
          || (ob->crashcnt < MAXCRASH && !PlaneIsKilled(ob->state)))) {
            winner(ob);
        } else {
            loser(ob);
        }
    }
}

static void TargetDestroyed(obj_t *ob)
{
    scoretarg(ob, ob->orient == 2 ? 200 : 100);

    numtarg[ob->faction]--;
    minimap_invalidate();               /* one fewer building to find */

    /*
     * Flattening every enemy building wins the level. Flattening your own
     * does not lose it, which sounds like an oversight but is what the
     * original does: only a faction with a pilot in it can win.
     */
    if (numtarg[FACTION_ENEMY] <= 0) {
        endgame(FACTION_PLAYER);
    }
}

/* How deep a bomb digs, across the eight pixels under it */
static const uint8_t crtdepth[8] = { 1, 2, 2, 3, 3, 2, 2, 1 };

static void crater(obj_t *ob)
{
    int16_t i, x, xmin, xmax, ymin;

    xmin = ob->x + ((SYM_W(ob) - 8) >> 1);
    xmax = xmin + 7;

    for (x = xmin, i = 0; x <= xmax; x++, i++) {
        if (x < 0 || x >= WORLD_W) {
            continue;
        }
        ymin = (int16_t)ground[x] - crtdepth[i] + 1;
        if (ymin <= PLAY_TOP) {
            ymin = PLAY_TOP + 1;        /* never dig into the status bar */
        }
        ground[x] = (uint8_t)(ymin - 1);
    }
}

/* A bullet still inside the plane that fired it is not a hit on it */
static bool_t IsYoungShot(obj_t *ob)
{
    return ob != NULL && ob->type == SHOT && ob->life >= BULLIFE - 1;
}

static void swkill(obj_t *ob, obj_t *obt)
{
    uint8_t ttype = obt != NULL ? obt->type : GROUND;
    uint8_t state;
    uint8_t i;

    if ((ttype == BIRD || ttype == FLOCK) && ob->type != PLANE) {
        return;
    }

    switch (ob->type) {

    case BOMB:
        initexpl(ob, FALSE);
        ob->life = -1;
        if (obt == NULL) {
            crater(ob);
        }
        sfx(SND_EXPLODE);
        return;

    case SHOT:
        if (!(obt != NULL && obt->type == PLANE && IsYoungShot(ob))) {
            ob->life = 1;
        }
        return;

    case EXPLOSION:
        if (obt == NULL) {
            ob->life = 1;
        }
        return;

    case TARGET:
        if (ob->state != STANDING || ttype == EXPLOSION) {
            return;
        }
        if (ttype == SHOT) {
            ob->hitcount += TARGHITCOUNT;
            if (ob->hitcount <= (TARGHITCOUNT * (gamenum + 1))) {
                return;
            }
        }
        ob->state = FINISHED;
        ob->flags &= ~OF_ONMAP;
        initexpl(ob, FALSE);
        sfx(SND_EXPLODE);
        TargetDestroyed(ob);
        return;

    case PLANE:
        state = ob->state;

        if (IsYoungShot(obt) || state == CRASHED || ob->endsts == WINNER) {
            return;
        }
        if (ttype == BIRD && (ob->flags & OF_ATHOME)) {
            return;
        }

        if (obt == NULL) {
            /* Hit the ground */
            if (state == FALLING) {
                initexpl(ob, TRUE);
                crater(ob);
            } else if (state < FINISHED) {
                scorepln(ob);
                initexpl(ob, TRUE);
                crater(ob);
            }
            crashpln(ob);
            sfx(SND_CRASH);
            return;
        }

        if (state >= FINISHED || state == FALLING) {
            return;
        }

        if (ttype != SHOT && ttype != BIRD && ttype != OX && ttype != FLOCK) {
            initexpl(ob, TRUE);
            if (ttype == PLANE && collptr < MAX_PLANES) {
                collxadj = -collxadj;
                collyadj = -collyadj;
                collsdx[collptr] = ((ob->dx + obt->dx) >> 1) + collxadj;
                collsdy[collptr] = ((ob->dy + obt->dy) >> 1) + collyadj;
                collsno[collptr] = ob;
                collptr++;
            }
        }

        hitpln(ob);
        scorepln(ob);
        if (ob == consoleplayer) {
            sfx(SND_HIT);
        }
        return;

    case BIRD:
        ob->life = scorepenalty(ttype, obt, 25) ? -1 : -2;
        return;

    case FLOCK:
        if (ttype != FLOCK && ttype != BIRD && ob->state == FLYING) {
            for (i = 0; i < 8; i++) {
                initbird(ob, i);
            }
            ob->life = -1;
            ob->state = FINISHED;
        }
        return;

    case OX:
        if (ob->state != STANDING || ttype == EXPLOSION) {
            return;
        }
        scorepenalty(ttype, obt, 200);
        ob->state = FINISHED;
        return;

    default:
        return;
    }
}

/* Has this object run into the hillside underneath it? */
static void tstcrash(obj_t *ob)
{
    int16_t x, y, w, h;
    const uint8_t *data;

    w = SYM_W(ob);
    h = SYM_H(ob);
    data = SYM_DATA(ob);

    for (x = 0; x < w; x++) {
        int16_t wx = x + ob->x;

        if (wx < 0 || wx >= WORLD_W) {
            continue;
        }

        y = ob->y - (int16_t)ground[wx];

        if (y >= h) {
            continue;                   /* this column clears the ground */
        }

        if (y < 0 || (data[y * 2 + (x >> 3)] & (0x80 >> (x & 7)))) {
            if (killptr < MAX_KILLS) {
                killed[killptr] = ob;
                killer[killptr] = NULL;
                killptr++;
            }
            return;
        }
    }
}

void swcollsn(void)
{
    obj_t *ob, *obp;
    int16_t xmax, ymin, ymax;
    uint8_t i, otype;

    killptr = 0;
    collptr = 0;
    collxadj = FX(2);
    collyadj = FX(1);
    if (countmove & 1) {
        collxadj = -collxadj;
        collyadj = -collyadj;
    }

    for (ob = topobj.xnext; ob != &botobj; ob = ob->xnext) {
        xmax = ob->x + SYM_W(ob) - 1;
        ymax = ob->y;
        ymin = ymax - SYM_H(ob) + 1;

        for (obp = ob->xnext;
             obp != &botobj && obp->x <= xmax;
             obp = obp->xnext) {

            if (obp->y >= ymin
             && (obp->y - SYM_H(obp) + 1) <= ymax
             && CollisionTest(ob, obp)
             && killptr < MAX_KILLS - 1) {
                killed[killptr] = ob;
                killer[killptr] = obp;
                killptr++;
                killed[killptr] = obp;
                killer[killptr] = ob;
                killptr++;
            }
        }

        otype = ob->type;

        if ((otype == PLANE
          && ob->state != FINISHED && ob->state != WAITING
          && ob->x + 8 < WORLD_W
          && ob->y < ((int16_t)ground[ob->x + 8] + 24))
         || (otype == BOMB
          && ob->x + 4 < WORLD_W
          && ob->y < ((int16_t)ground[ob->x + 4] + 12))) {
            tstcrash(ob);
        }
    }

    for (i = 0; i < killptr; i++) {
        swkill(killed[i], killer[i]);
    }

    for (i = 0; i < collptr; i++) {
        collsno[i]->dx = collsdx[i];
        collsno[i]->dy = collsdy[i];
    }
}
