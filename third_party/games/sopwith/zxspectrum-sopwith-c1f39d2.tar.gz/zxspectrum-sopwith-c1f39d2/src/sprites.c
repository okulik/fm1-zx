/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * ZX Sopwith - the sprite tables
 *
 * The pixel data and the frame tables are generated from src/sprites.txt by
 * tools/mksprites.py; this is the one place they are defined. The original
 * builds all of it at run time, rotating each shape four ways and mirroring
 * each of those, into one byte per pixel. That is around forty kilobytes of
 * work on a machine with forty-one, so it happens at build time here and
 * arrives packed to a bit a pixel.
 */

#include "sopwith.h"
#include "sprites.h"
