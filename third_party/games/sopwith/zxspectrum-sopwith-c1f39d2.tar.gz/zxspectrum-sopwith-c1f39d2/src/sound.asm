;
; Copyright (C) 2026 Neil Rackett
; SPDX-License-Identifier: GPL-3.0-or-later
;
; ZX Sopwith - the beeper
;
; The PC version keeps a running tone going, dropping and raising the pitch
; with the engine and layering explosions over it. The Spectrum's speaker is
; one bit that the processor has to toggle itself, so a continuous tone means
; a continuous loop and no game underneath it.
;
; What is here instead is one short effect per frame, chosen by priority the
; way the original chooses between competing sounds, kept to a few thousand
; cycles so the frame rate does not feel it.
;

        SECTION code_user

        PUBLIC  _snd_tone
        PUBLIC  _snd_noise

defc SPEAKER = $10                      ; bit 4 of port $FE; border stays black

; ---------------------------------------------------------------------------
; void snd_tone(uint16_t pitch, uint16_t cycles)
;
; A square wave: `cycles` half periods, each `pitch` units of delay long.
; ---------------------------------------------------------------------------
_snd_tone:
        ld      hl,2
        add     hl,sp
        ld      c,(hl)                  ; pitch
        inc     hl
        inc     hl
        ld      b,(hl)                  ; cycles
        ld      a,b
        or      a
        ret     z
        ld      e,0
tone_loop:
        ld      a,e
        xor     SPEAKER
        ld      e,a
        out     ($FE),a
        ld      a,c
tone_wait:
        dec     a
        jr      nz,tone_wait
        djnz    tone_loop
        xor     a
        out     ($FE),a
        ret

; ---------------------------------------------------------------------------
; void snd_noise(uint16_t seed, uint16_t cycles)
;
; Explosions and crashes want noise, not a note. A cheap linear feedback shift
; register drives the half period, so the pitch jitters and the ear hears a
; rush rather than a pitch.
; ---------------------------------------------------------------------------
_snd_noise:
        ld      hl,2
        add     hl,sp
        ld      c,(hl)                  ; seed
        inc     hl
        inc     hl
        ld      b,(hl)                  ; cycles
        ld      a,b
        or      a
        ret     z
        ld      e,0
        ld      d,c
        ld      c,$A9                   ; shift register, any non-zero value
noise_loop:
        ld      a,e
        xor     SPEAKER
        ld      e,a
        out     ($FE),a
        ld      a,c                     ; next pseudo-random period
        rlca
        xor     c
        rlca
        ld      c,a
        and     $1F
        add     a,d
noise_wait:
        dec     a
        jr      nz,noise_wait
        djnz    noise_loop
        xor     a
        out     ($FE),a
        ret
