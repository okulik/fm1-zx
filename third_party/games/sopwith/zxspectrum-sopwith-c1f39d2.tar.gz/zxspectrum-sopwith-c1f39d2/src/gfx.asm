;
; Copyright (C) 2026 Neil Rackett
; SPDX-License-Identifier: GPL-3.0-or-later
;
; ZX Sopwith - screen drawing
;
; Everything the game draws goes into a back buffer at the top of memory, laid
; out exactly like the display file so that showing a frame is one straight copy
; rather than an unpicking of the Spectrum's third-interleaved addressing. That
; costs a copy per frame and buys a picture that never tears: a frame takes
; longer to draw than a television field lasts, so drawing to the screen itself
; would show every sprite being erased before it was redrawn.
;
; The buffer occupies the last six kilobytes of memory, ending exactly at
; $FFFF, which is the only place left once code, sprites, the terrain and the
; object pool have had theirs. The base is a multiple of $800 so that the low
; three bits of a scanline address - the pixel row within a character - can be
; added into the high byte without disturbing it, which is what makes stepping
; down a row a single INC seven times in eight.
;
; These routines use the sdcc calling convention: arguments pushed right to
; left, the leftmost at SP+2, and the caller clears the stack. Every argument
; is declared 16 bits wide on the C side so that the offsets stay regular.
;

        SECTION code_user

        PUBLIC  _gfx_clear
        PUBLIC  _gfx_show
        PUBLIC  _gfx_sprite
        PUBLIC  _gfx_pixel
        PUBLIC  _gfx_char
        PUBLIC  _gfx_text
        PUBLIC  _gfx_hline
        PUBLIC  _gfx_ground
        PUBLIC  _gfx_blitmap
        PUBLIC  _gfx_border
        PUBLIC  _gfx_attr
        PUBLIC  _gfx_attrrow
        PUBLIC  _gnd_top

defc BUF      = $E800
defc BUFHI    = $E8
defc BUFEND   = (BUF + 6144) & $FFFF    ; $0000: the buffer ends at $FFFF
defc SCR      = $4000
defc BUFLEN   = 6144
defc FONT     = $3D00 - (32 * 8)        ; ROM font, biased so a code indexes it
defc PLAY_TOP = 25                      ; lowest world Y the ground fills to

; ---------------------------------------------------------------------------
; addr_hl - address of column zero of screen row A, within the back buffer
;
; offset = ((y & $C0) >> 3 | (y & 7)) * 256 + (y & $38) << 2, plus the base.
; The largest offset a 191 row screen can produce is $17E0, so adding the base
; in never carries out of the high byte.
;
; Corrupts A, HL. Everything else is preserved, which the callers rely on.
; ---------------------------------------------------------------------------
addr_hl:
        ld      l,a
        and     $07
        ld      h,a
        ld      a,l
        rrca
        rrca
        rrca
        and     $18
        or      h
        add     a,BUFHI
        ld      h,a
        ld      a,l
        rlca
        rlca
        and     $E0
        ld      l,a
        ret

; ---------------------------------------------------------------------------
; down_hl - move HL down one scanline
;
; Seven rows in eight that is a bump of the high byte and nothing else.
; Corrupts A only.
; ---------------------------------------------------------------------------
down_hl:
        inc     h
        ld      a,h
        and     $07
        ret     nz
        ld      a,l
        add     a,$20
        ld      l,a
        ret     c
        ld      a,h
        sub     $08
        ld      h,a
        ret

; ---------------------------------------------------------------------------
; void gfx_clear(uint16_t offset)
;
; Blank the buffer from `offset` to the end. Pushing zeroes clears two bytes
; per eleven cycles, twice what any move instruction manages, and is worth
; borrowing the stack pointer for. The DI is belt and braces - the game runs
; with interrupts off throughout - and there is deliberately no EI to match
; it, because switching them back on is how the ROM handler used to get in.
; ---------------------------------------------------------------------------
_gfx_clear:
        ld      hl,2
        add     hl,sp
        ld      c,(hl)
        inc     hl
        ld      b,(hl)                  ; BC = offset
        ld      hl,BUFLEN
        or      a
        sbc     hl,bc
        ret     z
        ret     c
        srl     h                       ; HL = bytes / 32, one block each
        rr      l
        srl     h
        rr      l
        srl     h
        rr      l
        srl     h
        rr      l
        srl     h
        rr      l
        ld      a,l
        or      a
        ret     z
        ld      b,a
        ld      (gfx_sp),sp
        di
        ld      sp,BUFEND
        ld      hl,0
clr_loop:
        push    hl
        push    hl
        push    hl
        push    hl
        push    hl
        push    hl
        push    hl
        push    hl
        push    hl
        push    hl
        push    hl
        push    hl
        push    hl
        push    hl
        push    hl
        push    hl
        djnz    clr_loop
        ld      sp,(gfx_sp)
        ret

; ---------------------------------------------------------------------------
; void gfx_show(uint16_t offset)
;
; Copy the buffer from `offset` to the end onto the screen. The caller passes
; the start of the topmost third anything was drawn in, so a frame flown close
; to the ground moves four kilobytes rather than six.
;
; Unrolled LDI runs a third faster than LDIR, and every length the caller can
; pass is a whole number of blocks, so the block counter is the LDI's own.
; ---------------------------------------------------------------------------
_gfx_show:
        ld      hl,2
        add     hl,sp
        ld      c,(hl)
        inc     hl
        ld      b,(hl)                  ; BC = offset
        ld      hl,BUFLEN
        or      a
        sbc     hl,bc
        ret     z
        ret     c
        ld      (gfx_len),hl
        ld      hl,BUF
        add     hl,bc
        ex      de,hl
        ld      hl,SCR
        add     hl,bc
        ex      de,hl                   ; HL = source, DE = screen
        ld      bc,(gfx_len)
show_blk:
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        ldi
        jp      pe,show_blk
        ret

; ---------------------------------------------------------------------------
; void gfx_sprite(int16_t sx, int16_t sy, const uint8_t *data, uint16_t rows)
;
; OR a sprite into the buffer. Sprites hold two bytes a row whatever their
; width, so a row lands in three screen bytes once shifted; sx may hang off
; either side and sy off either end, and the parts that do are dropped.
;
; The shift goes whichever way is shorter - right by sx&7, or left by 8-(sx&7)
; and read out of the registers in a different order - so no row is ever
; shifted more than four times, against seven for the obvious version.
; ---------------------------------------------------------------------------
_gfx_sprite:
        ld      hl,2
        add     hl,sp
        ld      de,spr_x
        ld      bc,8
        ldir                            ; stash sx, sy, data, rows

        ; --- clip the top: drop whole rows above the screen ---
        ld      hl,(spr_y)
        bit     7,h
        jr      z,spr_notop
        ld      a,h
        cpl
        ld      h,a
        ld      a,l
        cpl
        ld      l,a
        inc     hl                      ; HL = rows to skip
        ld      de,(spr_rows)
        ex      de,hl                   ; HL = rows, DE = skip
        or      a
        sbc     hl,de
        ret     z
        ret     c                       ; entirely above the screen
        ld      (spr_rows),hl
        ex      de,hl                   ; HL = skip
        add     hl,hl                   ; two bytes a row
        ld      de,(spr_data)
        add     hl,de
        ld      (spr_data),hl
        ld      hl,0
        ld      (spr_y),hl
spr_notop:
        ; --- clip the bottom ---
        ld      hl,(spr_y)
        ld      a,h
        or      a
        ret     nz                      ; starts far below the screen
        ld      a,l
        cp      192
        ret     nc
        ld      de,(spr_rows)
        add     hl,de
        ld      de,192
        or      a
        sbc     hl,de
        jr      c,spr_nobot
        jr      z,spr_nobot
        ex      de,hl                   ; DE = overhang
        ld      hl,(spr_rows)
        or      a
        sbc     hl,de
        ret     z
        ret     c
        ld      (spr_rows),hl
spr_nobot:
        ; --- column and shift ---
        ld      hl,(spr_x)
        ld      a,l
        and     $07
        ld      (spr_sh),a
        sra     h
        rr      l
        sra     h
        rr      l
        sra     h
        rr      l                       ; HL = sx >> 3, arithmetic
        ld      a,l
        ld      (spr_col),a

        ; --- which of the three output bytes are on screen ---
        add     a,2
        cp      32
        ld      c,0
        rl      c                       ; bit for column + 2
        ld      a,(spr_col)
        inc     a
        cp      32
        rl      c                       ; column + 1
        ld      a,(spr_col)
        cp      32
        rl      c                       ; column + 0, now in bit 0
        ld      a,c
        and     $07
        ld      (spr_mask),a
        ret     z                       ; entirely off the sides

        ; --- address of the first row drawn ---
        ld      a,(spr_y)
        call    addr_hl
        ld      a,(spr_col)
        ld      e,a
        rla
        sbc     a,a
        ld      d,a                     ; sign extended column
        add     hl,de
        ld      (spr_addr),hl

        ld      hl,(spr_data)
        ld      a,(spr_rows)
        or      a
        ret     z                       ; DJNZ would take a zero count as 256
        ld      b,a
        ld      a,(spr_mask)
        cp      $07
        jr      z,spr_fast

; --- clipped at one side: test each byte ----------------------------------
spr_slow:
        ld      d,(hl)
        inc     hl
        ld      e,(hl)
        inc     hl
        push    hl
        call    spr_shift               ; -> C, D, E
        ld      hl,(spr_addr)
        ld      a,(spr_mask)
        rra
        jr      nc,spr_s1
        ld      a,(hl)
        or      c
        ld      (hl),a
spr_s1:
        inc     hl
        ld      a,(spr_mask)
        rra
        rra
        jr      nc,spr_s2
        ld      a,(hl)
        or      d
        ld      (hl),a
spr_s2:
        inc     hl
        ld      a,(spr_mask)
        rra
        rra
        rra
        jr      nc,spr_s3
        ld      a,(hl)
        or      e
        ld      (hl),a
spr_s3:
        dec     hl
        dec     hl
        call    down_hl
        ld      (spr_addr),hl
        pop     hl
        djnz    spr_slow
        ret

; --- every byte on screen: no tests in the row loop -----------------------
spr_fast:
        ld      d,(hl)
        inc     hl
        ld      e,(hl)
        inc     hl
        push    hl
        call    spr_shift
        ld      hl,(spr_addr)
        ld      a,(hl)
        or      c
        ld      (hl),a
        inc     hl
        ld      a,(hl)
        or      d
        ld      (hl),a
        inc     hl
        ld      a,(hl)
        or      e
        ld      (hl),a
        dec     hl
        dec     hl
        call    down_hl
        ld      (spr_addr),hl
        pop     hl
        djnz    spr_fast
        ret

; Place the sprite row in D:E at bit offset spr_sh, leaving the three screen
; bytes in C, D and E in that order. Preserves B and HL.
spr_shift:
        ld      c,0
        ld      a,(spr_sh)
        cp      5
        jr      nc,spr_shl
        or      a
        jr      z,spr_shrot
spr_shr:
        srl     d
        rr      e
        rr      c
        dec     a
        jr      nz,spr_shr
spr_shrot:
        ld      a,d                     ; right shifts land as D:E:C
        ld      d,e
        ld      e,c
        ld      c,a
        ret
spr_shl:
        neg
        add     a,8                     ; 1..3 places the other way
spr_shl1:
        sla     e
        rl      d
        rl      c
        dec     a
        jr      nz,spr_shl1
        ret                             ; left shifts land as C:D:E already

; ---------------------------------------------------------------------------
; void gfx_pixel(int16_t sx, int16_t sy)
;
; Bullets and smoke are single pixels and there are a great many of them, so
; they skip the sprite path.
; ---------------------------------------------------------------------------
_gfx_pixel:
        ld      hl,2
        add     hl,sp
        ld      e,(hl)
        inc     hl
        ld      d,(hl)                  ; DE = sx
        inc     hl
        ld      c,(hl)
        inc     hl
        ld      a,(hl)                  ; A = high byte of sy
        or      d
        ret     nz                      ; either coordinate out of range
        ld      a,c
        cp      192
        ret     nc
        push    de
        call    addr_hl
        pop     de
        ld      a,e
        rrca
        rrca
        rrca
        and     $1F
        add     a,l
        ld      l,a
        ld      a,e
        and     $07
        ld      b,a
        ld      a,$80
        inc     b
pix_sh:
        dec     b
        jr      z,pix_do
        rrca
        jr      pix_sh
pix_do:
        or      (hl)
        ld      (hl),a
        ret

; ---------------------------------------------------------------------------
; void gfx_char(uint16_t cx, uint16_t cy, uint16_t ch)
;
; One ROM font character, replacing what was underneath. All the game's text
; is character aligned, which is why the status bar is 24 pixels tall rather
; than the 19 the PC version uses.
; ---------------------------------------------------------------------------
_gfx_char:
        ld      hl,2
        add     hl,sp
        ld      c,(hl)                  ; cx
        inc     hl
        inc     hl
        ld      b,(hl)                  ; cy
        inc     hl
        inc     hl
        ld      e,(hl)
        inc     hl
        ld      d,(hl)                  ; DE = character code
        ld      a,c
        cp      32
        ret     nc
        ld      a,b
        cp      24
        ret     nc
        ex      de,hl
        add     hl,hl
        add     hl,hl
        add     hl,hl
        ld      de,FONT
        add     hl,de
        push    hl                      ; the glyph
        ld      a,b
        add     a,a
        add     a,a
        add     a,a                     ; top scanline of the character row
        call    addr_hl
        ld      b,0
        add     hl,bc                   ; plus the column
        pop     de
        ld      b,8
        ;
        ; A character starts on a character row, so all eight of its scanlines
        ; are inside one cell and stepping down is a bare INC H: no boundary
        ; can fall in the middle of a glyph.
        ;
chr_loop:
        ld      a,(de)
        ld      (hl),a
        inc     de
        inc     h
        djnz    chr_loop
        ret

; ---------------------------------------------------------------------------
; void gfx_text(uint16_t cx, uint16_t cy, const char *s)
;
; A whole string for one screen address. The status bar draws three dozen
; characters a frame, and gfx_char pays a call, an argument fetch off the
; stack and a scanline address calculation for every one of them - about four
; times what the eight stores actually cost. Here that is paid once and a
; column is one INC L.
;
; The eight scanlines of a character row are all inside one cell, so stepping
; down is a bare INC H; eight of those overshoot the cell, so the high byte is
; wound back by eight before moving along.
; ---------------------------------------------------------------------------
_gfx_text:
        ld      hl,2
        add     hl,sp
        ld      c,(hl)                  ; cx
        inc     hl
        inc     hl
        ld      b,(hl)                  ; cy
        inc     hl
        inc     hl
        ld      e,(hl)
        inc     hl
        ld      d,(hl)                  ; DE = the string
        ld      a,c
        cp      32
        ret     nc
        ld      a,b
        cp      24
        ret     nc
        add     a,a
        add     a,a
        add     a,a                     ; top scanline of the row
        call    addr_hl
        ld      b,0
        add     hl,bc                   ; plus the column
        ld      a,32
        sub     c
        ld      c,a                     ; columns left before the row ends

txt_char:
        ld      a,c
        or      a
        ret     z
        ld      a,(de)
        or      a
        ret     z                       ; end of string
        inc     de
        dec     c
        push    de
        push    hl
        ld      l,a                     ; glyph = FONT + code * 8
        ld      h,0
        add     hl,hl
        add     hl,hl
        add     hl,hl
        ld      de,FONT
        add     hl,de
        ex      de,hl
        pop     hl
        ld      b,8
txt_row:
        ld      a,(de)
        ld      (hl),a
        inc     de
        inc     h
        djnz    txt_row
        ld      a,h
        sub     8
        ld      h,a                     ; back to the top of the cell
        inc     l                       ; and along one column
        pop     de
        jr      txt_char

; ---------------------------------------------------------------------------
; void gfx_attrrow(uint16_t row, const uint8_t *src)
;
; Put 32 prepared attribute bytes into one character row.
;
; The attribute file is the one thing on screen that is not double buffered -
; there is no memory left to buffer it with - so the ULA reads it while it is
; being written. Blanking a row and then stamping colour back into it makes
; every coloured cell flash white for however much of the frame separates the
; two, which reads as a hard flicker. So the row arrives already correct and
; each cell is written exactly once, and the worst the ULA can catch is the
; boundary between two frames' worth of colour.
; ---------------------------------------------------------------------------
_gfx_attrrow:
        ld      hl,2
        add     hl,sp
        ld      a,(hl)                  ; row
        inc     hl
        inc     hl
        ld      e,(hl)
        inc     hl
        ld      d,(hl)                  ; DE = the prepared bytes
        cp      24
        ret     nc
        ld      l,a                     ; $5800 + row * 32
        ld      h,0
        add     hl,hl
        add     hl,hl
        add     hl,hl
        add     hl,hl
        add     hl,hl
        ld      bc,$5800
        add     hl,bc
        ex      de,hl
        ld      bc,32
        ldir
        ret

; ---------------------------------------------------------------------------
; void gfx_attr(uint16_t cx, uint16_t cy, uint16_t w, uint16_t h, uint16_t a)
;
; Paint a block of the attribute file. The play field is repainted with the
; background colour each frame and every plane and building then stamps its
; own cells, which is what gives the two sides their colours - at the price of
; whatever else shares those cells taking them too.
;
; The caller clips; this only guards the edges of the file itself.
; ---------------------------------------------------------------------------
_gfx_attr:
        ld      hl,2
        add     hl,sp
        ld      de,att_cx
        ld      bc,10
        ldir

        ld      a,(att_cx)
        cp      32
        ret     nc
        ld      a,(att_cy)
        cp      24
        ret     nc

        ; $5800 + cy * 32 + cx
        ld      l,a
        ld      h,0
        add     hl,hl
        add     hl,hl
        add     hl,hl
        add     hl,hl
        add     hl,hl
        ld      a,(att_cx)
        ld      e,a
        ld      d,0
        add     hl,de
        ld      de,$5800
        add     hl,de

        ld      a,(att_h)
        or      a
        ret     z
        ld      b,a
        ld      a,(att_a)
        ld      c,a
att_row:
        push    hl
        ld      a,(att_w)
        or      a
        jr      z,att_next
att_col:
        ld      (hl),c
        inc     hl
        dec     a
        jr      nz,att_col
att_next:
        pop     hl
        ld      a,l                     ; down one character row
        add     a,32
        ld      l,a
        jr      nc,att_norm
        inc     h
att_norm:
        djnz    att_row
        ret

; ---------------------------------------------------------------------------
; void gfx_border(uint16_t colour)
; ---------------------------------------------------------------------------
_gfx_border:
        ld      hl,2
        add     hl,sp
        ld      a,(hl)
        and     $07
        out     ($FE),a
        ret

; ---------------------------------------------------------------------------
; void gfx_hline(uint16_t row)
; ---------------------------------------------------------------------------
_gfx_hline:
        ld      hl,2
        add     hl,sp
        ld      a,(hl)
        cp      192
        ret     nc
        call    addr_hl
        ld      b,32
        ld      a,$FF
hln_loop:
        ld      (hl),a
        inc     hl
        djnz    hln_loop
        ret

; ---------------------------------------------------------------------------
; void gfx_ground(const uint8_t *heights)
;
; Draw the terrain under the current view, a byte column at a time: a solid
; line along the surface and a dithered fill beneath it, down to the status
; bar. A checkerboard rather than solid white, because a third of the screen
; in flat white glares on a television, and this reads as ground.
;
; The eight surfaces inside one byte column usually differ by a pixel or two.
; Rather than ask "which of these eight are underground?" once a row, a single
; pass over the heights records where each surface ends, indexed by row. Then
; walking down from the highest and accumulating those entries gives the
; underground mask for the price of an OR a row, and the same entry is the
; surface line, which is written solid so the horizon survives the dither.
;
; Below the lowest surface every pixel is underground, and that is the long
; run - twenty five rows or so - which costs one store a row.
; ---------------------------------------------------------------------------
_gfx_ground:
        ld      hl,2
        add     hl,sp
        ld      a,(hl)
        inc     hl
        ld      h,(hl)
        ld      l,a
        push    ix
        push    hl
        pop     ix                      ; IX = &ground[displx]
        xor     a
        ld      (gnd_col),a
        ld      (_gnd_top),a            ; highest ground in view, for the blit

gnd_column:
        ; --- highest and lowest surface in this byte ---
        ld      a,(ix+0)
        ld      b,a                     ; highest
        ld      c,a                     ; lowest
        push    ix
        ld      e,7
gnd_mm:
        inc     ix
        ld      a,(ix+0)
        cp      b
        jr      c,gnd_mm1
        ld      b,a
gnd_mm1:
        cp      c
        jr      nc,gnd_mm2
        ld      c,a
gnd_mm2:
        dec     e
        jr      nz,gnd_mm
        pop     ix
        ld      a,b
        ld      (gnd_max),a
        ld      a,c
        ld      (gnd_min),a

        ld      a,(_gnd_top)
        cp      b
        jr      nc,gnd_notop
        ld      a,b
        ld      (_gnd_top),a
gnd_notop:

        ; --- record where each of the eight surfaces ends ---
        ld      a,b
        sub     c
        inc     a                       ; rows from the lowest to the highest
        ld      b,a
        ld      hl,gnd_tbl
        xor     a
gnd_tclr:
        ld      (hl),a
        inc     hl
        djnz    gnd_tclr

        push    ix
        ld      b,8
        ld      c,$80                   ; leftmost pixel of the byte
        ld      a,(gnd_min)
        ld      e,a
gnd_tset:
        ld      a,(ix+0)
        sub     e                       ; height above the lowest surface
        ld      hl,gnd_tbl
        add     a,l
        ld      l,a
        ld      a,h
        adc     a,0
        ld      h,a
        ld      a,(hl)
        or      c
        ld      (hl),a
        inc     ix
        srl     c
        djnz    gnd_tset
        pop     ix

        ; --- the topmost row this column touches ---
        ld      a,(gnd_max)
        ld      b,a
        ld      a,191
        sub     b
        ld      c,a                     ; screen row, kept for the dither
        call    addr_hl
        ld      a,(gnd_col)
        ld      e,a
        ld      d,0
        add     hl,de                   ; HL = that row, this column

        ; The dither follows the screen row rather than the column, so the
        ; pattern lines up across the width however the ground rises and falls.
        ld      a,c
        rrca
        ld      a,$AA
        jr      nc,gnd_phase
        ld      a,$55
gnd_phase:
        ld      (gnd_pat),a

        ; --- the rows the eight surfaces are spread over ---
        ld      a,(gnd_max)
        ld      e,a
        ld      a,(gnd_min)
        neg
        add     a,e                     ; A = max - min
        ld      b,a
        inc     b                       ; rows to draw
        push    hl                      ; the screen address
        ld      hl,gnd_tbl
        ld      e,a
        ld      d,0
        add     hl,de
        ex      de,hl                   ; DE = &tbl[max - min], walking down
        pop     hl
        ld      c,0                     ; underground so far
gnd_part:
        ld      a,(de)
        or      c
        ld      c,a                     ; every surface at or above this row
        ;
        ; Only the underground bits may be written. Objects are drawn before
        ; the ground and the sky half of this byte can already hold a bullet
        ; or a wingtip, so the sky bits are read back and kept rather than
        ; replaced - otherwise anything crossing a slope loses whole bytes of
        ; itself. Below the lowest surface every bit is underground and a
        ; plain store is the correct occlusion.
        ;
        cpl
        and     (hl)                    ; whatever was already in the sky
        ld      (hl),a
        ld      a,(gnd_pat)
        and     c
        or      (hl)
        ld      (hl),a
        ld      a,(de)
        or      (hl)                    ; the surface line, drawn solid
        ld      (hl),a
        ld      a,(gnd_pat)
        rlca
        ld      (gnd_pat),a
        dec     de
        dec     b
        jr      z,gnd_full
        call    down_hl
        jr      gnd_part

        ; --- everything below the lowest surface is solid ---
gnd_full:
        ld      a,(gnd_min)
        cp      PLAY_TOP + 1
        jr      c,gnd_next
        sub     PLAY_TOP
        ld      c,a                     ; rows still to fill
        ld      a,(gnd_pat)
        ld      d,a
        cpl
        ld      e,a                     ; the dither's two phases, both held
        ;
        ; This is the long loop of the routine - twenty five rows a column,
        ; thirty two columns, and by some way the most bytes it writes. Two
        ; things keep it short. Within a character cell, down a scanline is a
        ; bump of the high byte, so the awkward boundary case is worked out
        ; once a cell rather than tested once a row. And with both dither
        ; phases in registers a pair of rows is four instructions, so no row
        ; pays for a rotate or a counter test of its own.
        ;
        call    down_hl                 ; onto the first row to fill
gnd_cell:
        ld      a,h
        and     $07
        ld      b,a
        ld      a,8
        sub     b                       ; rows left in this character cell
        cp      c
        jr      c,gnd_run
        ld      a,c                     ; fewer rows wanted than remain
gnd_run:
        ld      b,a
        ld      a,c
        sub     b
        ld      c,a                     ; rows still to do after this cell
        srl     b
        jr      nc,gnd_pairs
        ld      (hl),d                  ; odd row first, then swap the phases
        inc     h
        ld      a,d
        ld      d,e
        ld      e,a
gnd_pairs:
        ld      a,b
        or      a
        jr      z,gnd_cellend
gnd_pair:
        ld      (hl),d
        inc     h
        ld      (hl),e
        inc     h
        djnz    gnd_pair
gnd_cellend:
        ld      a,c
        or      a
        jr      z,gnd_next
        ;
        ; The row stores walked the high byte off the end of the cell, so the
        ; move to the next one is the same fixup down_hl does at a boundary.
        ;
        ld      a,l
        add     a,$20
        ld      l,a
        jr      c,gnd_cell
        ld      a,h
        sub     $08
        ld      h,a
        jr      gnd_cell

gnd_next:
        ld      de,8
        add     ix,de
        ld      a,(gnd_col)
        inc     a
        ld      (gnd_col),a
        cp      32
        jp      c,gnd_column
        pop     ix
        ret

; ---------------------------------------------------------------------------
; void gfx_blitmap(const uint8_t *src, uint16_t row, uint16_t rows,
;                  uint16_t col, uint16_t bytes)
;
; Drop a small pre-rendered bitmap into the buffer. The minimap is the only
; caller: its picture only changes when the ground does, so it is drawn once
; into a scratch bitmap and moved in whole from there every frame.
; ---------------------------------------------------------------------------
_gfx_blitmap:
        ld      hl,2
        add     hl,sp
        ld      de,map_src
        ld      bc,10
        ldir

        ld      a,(map_row)
        call    addr_hl
        ld      a,(map_col)
        ld      e,a
        ld      d,0
        add     hl,de                   ; HL = top left corner
        ld      de,(map_src)
        ld      a,(map_rows)
        ld      b,a
map_line:
        push    bc
        push    hl
        ld      a,(map_bytes)
        ld      b,a
map_byte:
        ld      a,(de)
        ld      (hl),a
        inc     de
        inc     hl
        djnz    map_byte
        pop     hl
        call    down_hl
        pop     bc
        djnz    map_line
        ret

        SECTION bss_user

_gnd_top:       defs 1

map_src:        defs 2
map_row:        defs 2
map_rows:       defs 2
map_col:        defs 2
map_bytes:      defs 2

gfx_sp:         defs 2
gfx_len:        defs 2

spr_x:          defs 2
spr_y:          defs 2
spr_data:       defs 2
spr_rows:       defs 2
spr_sh:         defs 1
spr_col:        defs 1
spr_mask:       defs 1
spr_addr:       defs 2

gnd_col:        defs 1
gnd_pat:        defs 1

att_cx:         defs 2
att_cy:         defs 2
att_w:          defs 2
att_h:          defs 2
att_a:          defs 2
gnd_max:        defs 1
gnd_min:        defs 1

; One entry per row between the lowest and highest surface of a byte column.
; The map's own cliffs only ever span 13 rows within one byte; the case that
; needs the full screen is a bombed hillside, where a crater can dig a column
; down to PLAY_TOP while the one beside it still stands at 190.
gnd_tbl:        defs 192
