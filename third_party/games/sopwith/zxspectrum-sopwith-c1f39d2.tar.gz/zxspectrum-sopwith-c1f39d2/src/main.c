/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * ZX Sopwith - Sopwith for the ZX Spectrum 48K
 *
 * A port of atarist-sopwith, which came from sdl-sopwith, which came from the
 * 1984 DOS original by David L. Clark.
 *
 * Copyright (C) 1984-2000 David L. Clark
 * Copyright (C) 2001-2005 Simon Howard
 */

#include "sopwith.h"
#include "gfx.h"
#include "render.h"

/*
 * There is no frame timer. The original holds itself to ten frames a second
 * against one, and this used the ROM's fifty hertz counter for the same job -
 * but that counter is only maintained by the ROM's interrupt handler, and
 * that handler cannot be allowed to run here. See sys_init in keys.asm.
 *
 * Nothing is lost by dropping the cap. Clearing the buffer, drawing the
 * ground, the status bar and copying the frame to the screen come to about
 * three hundred thousand T states before a single object has moved, so the
 * frame cannot finish inside a tenth of a second whatever is on screen: the
 * limit this loop enforced was never once reached. If the drawing is ever
 * made fast enough to reach it, the cap comes back as an IM 2 handler of our
 * own rather than the ROM's.
 */

static void titlescreen(void)
{
    uint8_t k;

    setattrs_title();
    gfx_clear(0);

    puttext(6, 1, "Z X   S O P W I T H");

    /*
     * A dogfight across the top, the way the original dresses its title
     * screen. It has to live in the two character rows nothing else uses:
     * everything below is text, and a sprite dropped on top of a line of it
     * would simply overwrite the letters.
     */
    gfx_sprite(20, 24, spr_plane[2].data, spr_plane[2].h);
    gfx_sprite(212, 24, spr_plane[16 + 6].data, spr_plane[16 + 6].h);
    gfx_attr(2, 3, 3, 2, ATTR_MINE);    /* so the colours are learned here, */
    gfx_attr(26, 3, 3, 2, ATTR_THEIRS); /* before they matter               */
    gfx_hline(46);

    puttext(1, 7,  "Q  PULL UP     P  THROTTLE UP");
    puttext(1, 8,  "A  PULL DOWN   O  THROTTLE DOWN");
    puttext(1, 9,  "F  FLIP OVER   H  FLY HOME");
    puttext(1, 10, "SPACE  FIRE    B  DROP BOMB");
    puttext(1, 11, "M  SOUND       1  ABANDON");

    puttext(5, 13, "N  NOVICE PLAYER");
    puttext(5, 14, "E  EXPERT PLAYER");
    puttext(5, 15, "C  VERSUS THE COMPUTER");

    puttext(5, 17, "HI-SCORE");
    putnum(14, 17, hiscore, 7);

    puttext(0, 19, "(c) 1984,85,87 BMB Compuscience");
    puttext(0, 20, "(c) 1984-2000 David L. Clark");
    puttext(0, 21, "(c) 2001-2005 Simon Howard");
    puttext(0, 22, "(c) 2026 Neil Rackett");
    puttext(0, 23, "Distributed under the GNU GPL");

    gfx_show(0);

    waitnokey();
    k = waitkey();
    waitnokey();

    switch (k) {
    case 'N': playmode = PLAYMODE_NOVICE;   break;
    case 'E': playmode = PLAYMODE_SINGLE;   break;
    case 'C': playmode = PLAYMODE_COMPUTER; break;
    default:  playmode = PLAYMODE_SINGLE;   break;
    }

    sfx(SND_MENU);
    sfx_frame();

    score = 0;
    gamenum = 0;
}

int main(void)
{
    /*
     * Set explicitly rather than left to the startup code to zero: a tape
     * loads into whatever the previous program left behind, and a wrong play
     * mode here would start a game with nobody at the controls.
     */
    playmode = PLAYMODE_UNSET;
    score = 0;
    hiscore = 0;
    gamenum = 0;
    soundflg = TRUE;
    explseed = 7491;

    /*
     * Interrupts drive the frame counter, and the ROM's handler needs IY
     * pointing at the system variables before any of them are let through.
     */
    sys_init();
    gfx_border(0);

    for (;;) {
        if (playmode == PLAYMODE_UNSET) {
            titlescreen();
        }

        swinitlevel();
        restart_flag = FALSE;

        while (!restart_flag) {
            swmove();
            swdisp();
            swcollsn();
            sfx_frame();
        }
    }
}
