/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * ZX Sopwith - Sopwith for the ZX Spectrum 48K
 *
 * A port of atarist-sopwith, which is itself a port of sdl-sopwith, which is
 * a port of the 1984 DOS original.
 *
 * Copyright (C) 1984-2000 David L. Clark
 * Copyright (C) 2001-2005 Simon Howard
 *
 * The original game is distributed under the GNU General Public License
 * version 2 or later; this port is version 3 or later, as that licence
 * permits.
 */

#ifndef SOPWITH_H
#define SOPWITH_H

#include <stddef.h>
#include <stdint.h>

typedef unsigned char bool_t;
#define TRUE  1
#define FALSE 0

/* --- Screen and world geometry --------------------------------------- */

/*
 * The Spectrum's 256x192 bitmap replaces the PC's 320x200. The status bar
 * keeps its place at the bottom of the screen and grows from 19 pixels to a
 * whole 24, so that it lands on character boundaries and its text can be
 * blitted a byte at a time rather than shifted.
 *
 * World Y counts upwards from the bottom of the screen, as it does in the
 * original: y == 0 is the last scanline, y == MAX_Y - 1 the first. Screen row
 * is therefore SCR_H - 1 - y, and the ground profile reads directly as a Y
 * coordinate with no adjustment.
 */

#define SCR_W       256
#define SCR_H       192
#define STATUS_H    24                  /* bottom of the screen           */
#define PLAY_TOP    25                  /* lowest world Y the ground fills
                                           to; also in gfx.asm             */
#define MAX_Y       192                 /* ceiling; planes stall above it */

#define SCR_CENTR   ((SCR_W / 2) - 8)   /* where the player is kept       */

#define WORLD_W     3000                /* ground[] entries               */

/* --- Game constants, from the original ------------------------------- */

#define FPS             10
#define MIN_SPEED       4
#define MAX_SPEED       8
#define MAX_THROTTLE    4

#define MAXCRCOUNT      10              /* turns spent crashed            */
#define FALLCOUNT       10              /* moves between falling adjusts  */
#define STALLCOUNT      6               /* moves between stall adjusts    */
#define TARGHITCOUNT    10              /* hits before a target explodes  */

#define MAXROUNDS       200
#define MAXBOMBS        5
#define MAXFUEL         9000
#define MAXCRASH        5

#define ANGLES          16
#define BULSPEED        10
#define BULLIFE         10
#define BOMBLIFE        5
#define EXPLLIFE        3
#define SMOKELIFE       10
#define BIRDLIFE        4
#define FLOCKLIFE       5

#define NEAR            (150 * 150)     /* computer control distances     */
#define CLOSE           32
#define HOME            16
#define SAFERESET       32

#define QUIT            -5000           /* fuel value meaning "gave up"   */

/*
 * The object pool. The original allows a hundred objects and mallocs more if
 * it runs out; here the pool is all there is, and its size is set by whatever
 * memory was left over. The map places 34 of these before play starts - 20
 * buildings, four flocks and their strays, two oxen and four planes - leaving
 * 30 for the shots, bombs, smoke and explosion fragments in the air at any
 * moment. Running dry is not fatal: every allocation site copes with a
 * refusal, because the DOS version could refuse too.
 */
#define MAX_OBJS        64
#define MAX_PLANES      6

/* --- Object types and states ----------------------------------------- */

enum {
    GROUND = 0, PLANE, BOMB, SHOT, TARGET, EXPLOSION, SMOKE, FLOCK, BIRD, OX
};

/* The original's WOUNDED and REBUILDING states went with the features that
   used them; the gaps are left so the numbering still matches it. */
enum {
    WAITING = 0, FLYING, CRASHED = 3, FALLING, STANDING, STALLED,
    FINISHED = 91
};

enum { PLAYING = 0, WINNER, LOSER };

enum { FACTION_NONE = 0, FACTION_PLAYER, FACTION_ENEMY };

enum {
    PLAYMODE_UNSET = 0, PLAYMODE_NOVICE, PLAYMODE_SINGLE, PLAYMODE_COMPUTER
};

/* Keyboard command bits, as gathered once per tic */
#define K_ACCEL     0x0001
#define K_DEACC     0x0002
#define K_FLAPU     0x0004
#define K_FLAPD     0x0008
#define K_FLIP      0x0010
#define K_SHOT      0x0020
#define K_BOMB      0x0040
#define K_HOME      0x0080
#define K_BREAK     0x0200

/* Object flag bits */
#define OF_DRAW     0x01                /* was moved, so should be drawn  */
#define OF_ONMAP    0x02                /* appears on the minimap         */
#define OF_HOME     0x04                /* autopilot engaged              */
#define OF_ATHOME   0x08                /* sitting on its own runway      */
#define OF_BOMBING  0x10                /* asked to drop a bomb this tic  */
#define OF_GOINGSUN 0x20                /* won, and flying into the sun   */
#define OF_FIRING   0x40                /* fired this tic; drives sound   */
#define OF_COMPUTER 0x80                /* flown by the computer          */

/* --- Sprites ---------------------------------------------------------- */

/*
 * Two bytes a row whatever the width, left aligned, so the blitter has one
 * shape to draw. Width is still carried because collision detection and
 * centring both need the real extent.
 */
typedef struct {
    uint8_t w, h;
    const uint8_t *data;
} sprite_t;

extern const sprite_t spr_plane[32];    /* [orient * 16 + angle]          */
extern const sprite_t spr_planehit[4];
extern const sprite_t spr_planewin[4];
extern const sprite_t spr_bomb[8];      /* [angle 0..7]                   */
extern const sprite_t spr_target[8];    /* [type * 2 + mirrored]          */
extern const sprite_t spr_targhit[2];
extern const sprite_t spr_debris[8];
extern const sprite_t spr_flock[2];
extern const sprite_t spr_bird[2];
extern const sprite_t spr_ox[2];

/* --- Objects ---------------------------------------------------------- */

/*
 * Positions are whole pixels plus a byte of fraction; velocities are 8.8
 * fixed point in pixels per tic. The original carries a full 16.16 position
 * and a 16.16 velocity, which is more precision than ten frames a second
 * needs and twice the arithmetic on a Z80.
 */
#define FX(n)   ((int16_t)((n) * 256))  /* whole pixels per tic, as 8.8   */

typedef struct {
    uint8_t  type;
    uint8_t  orient;                    /* target type, or plane facing   */
    int16_t  x;
    int16_t  territory_l, territory_r;  /* where a computer plane patrols */
    uint8_t  faction;
    uint8_t  mirrored;
} orig_ob_t;

typedef struct obj {
    struct obj *next, *prev;            /* creation order                 */
    struct obj *xnext, *xprev;          /* sorted by X, for collisions    */
    /*
     * What a computer plane is chasing - and, for a puff of smoke, the plane
     * it came off, since smoke has no use for a target and a second pointer
     * on every object costs 128 bytes there is nowhere to find.
     */
    struct obj *target;
    const sprite_t *sym;
    const orig_ob_t *orig;

    int16_t  x, y;                      /* world pixels                   */
    uint8_t  xf, yf;                    /* fraction of a pixel, 0..255    */
    int16_t  dx, dy;                    /* pixels per tic, 8.8            */

    int16_t  life;                      /* fuel, or ticks left to live    */
    int16_t  hitcount;
    uint8_t  rounds;
    uint8_t  orig_y;                    /* where this object took off     */

    uint8_t  type;
    uint8_t  state;
    uint8_t  orient;
    uint8_t  angle;
    int8_t   speed;
    int8_t   accel;
    int8_t   flaps;
    uint8_t  faction;
    uint8_t  bombs;
    uint8_t  crashcnt;
    uint8_t  bdelay;
    uint8_t  flags;
    uint8_t  endsts;
} obj_t;

/* --- Globals ---------------------------------------------------------- */

extern uint8_t  ground[WORLD_W];
extern obj_t   *objtop, *objbot;
extern obj_t    topobj, botobj;         /* sentinels for the X list       */
extern obj_t   *planes[MAX_PLANES];
extern uint8_t  num_planes;
extern obj_t   *consoleplayer;

extern uint8_t  playmode;
extern uint8_t  gamenum;                /* level number, from zero        */
extern int8_t   gmaxspeed, gminspeed;
extern int16_t  targrnge;
extern int16_t  numtarg[3];             /* live targets, by faction       */
extern uint16_t countmove;
extern int16_t  displx;                 /* left edge of the view          */
extern int16_t  endcount;
extern int16_t  score;
extern int16_t  hiscore;
extern bool_t   soundflg;
extern bool_t   restart_flag;
extern bool_t   compplane, plyrplane;
extern uint8_t  endstat;
extern uint16_t explseed;

extern const int16_t sintab[ANGLES];

/* --- Small helpers ---------------------------------------------------- */

int16_t imin(int16_t a, int16_t b);
int16_t imax(int16_t a, int16_t b);
int16_t iabs(int16_t a);

#define clamp_min   imax
#define clamp_max   imin
#define clamp_range(lo, v, hi) imax(lo, imin(v, hi))
#define in_range(lo, v, hi)    ((v) >= (lo) && (v) <= (hi))

#define SIN(a)  sintab[(a) & (ANGLES - 1)]
#define COS(a)  sintab[((a) + ANGLES / 4) & (ANGLES - 1)]

bool_t PlaneIsKilled(uint8_t state);
bool_t PlaneIsStalled(uint8_t state);

/* --- objects.c -------------------------------------------------------- */

void    initobjs(void);
obj_t  *allocobj(void);
void    deallobj(obj_t *ob);
void    insertx(obj_t *ob, obj_t *near);
obj_t  *deletex(obj_t *ob);
void    updateobjpos(obj_t *ob);
void    movexy(obj_t *ob);
void    setdxdy(obj_t *ob, int16_t dx, int16_t dy);
void    copyobj(obj_t *to, obj_t *from);
void    reapobjs(void);

/* --- level.c ---------------------------------------------------------- */

extern const orig_ob_t level_objects[];
extern const uint8_t   level_num_objects;

void    initgrnd(void);

/* --- game.c ----------------------------------------------------------- */

void    swinitlevel(void);
void    swmove(void);
void    swrestart(void);

obj_t  *initpln(obj_t *obp, const orig_ob_t *orig);
void    initplyr(obj_t *obp, const orig_ob_t *orig);
void    initcomp(obj_t *obp, const orig_ob_t *orig);
void    initshot(obj_t *obo, obj_t *targ);
void    initbomb(obj_t *obo);
void    initexpl(obj_t *obo, bool_t small);
void    initsmok(obj_t *obo);
void    initbird(obj_t *obo, uint8_t i);
bool_t  crashpln(obj_t *ob);
bool_t  hitpln(obj_t *ob);

/* --- auto.c ----------------------------------------------------------- */

void    swauto(obj_t *ob);
int16_t aim(obj_t *ob, int16_t ax, int16_t ay, obj_t *obt, bool_t longway);
int16_t gohome(obj_t *ob);
int16_t range(int16_t x, int16_t y, int16_t ax, int16_t ay);

/* --- collide.c -------------------------------------------------------- */

void    swcollsn(void);
bool_t  CollisionTest(obj_t *ob1, obj_t *ob2);
void    scorepln(obj_t *ob);
void    endgame(uint8_t winning_faction);
void    winner(obj_t *ob);
void    loser(obj_t *ob);

/* --- render.c --------------------------------------------------------- */

void    initdisp(void);
void    swdisp(void);
void    setattrs(void);
void    setattrs_title(void);
void    puttext(uint8_t cx, uint8_t cy, const char *s);
void    putnum(uint8_t cx, uint8_t cy, int16_t v, uint8_t width);

/* --- sound.c ---------------------------------------------------------- */

/* In priority order: only the most important effect of a tic is played */
enum { SND_EXPLODE = 0, SND_CRASH, SND_BOMB, SND_HIT, SND_SHOT, SND_MENU };

void    sfx(uint8_t which);
void    sfx_frame(void);

/* --- keys.c ----------------------------------------------------------- */

uint16_t getgamekeys(void);
void     waitnokey(void);
uint8_t  waitkey(void);

#endif
