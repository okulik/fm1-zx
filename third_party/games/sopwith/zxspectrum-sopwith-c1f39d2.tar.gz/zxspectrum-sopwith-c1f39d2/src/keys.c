/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * ZX Sopwith - controls
 *
 * The DOS keys are comma, full stop and slash, which on a rubber keyboard are
 * all symbol shifted and so unplayable. These are the nearest thing to them
 * that a Spectrum can hold down three at a time:
 *
 *   Q / A     pull up, pull down
 *   P / O     throttle up, down
 *   F         flip the plane over
 *   SPACE     machine gun
 *   B         drop a bomb
 *   H         fly home
 *   M         sound on and off
 *   1         abandon the flight
 *
 * A Kempston joystick flies the plane and fires, and the keyboard stays live
 * alongside it for the four things one button cannot reach.
 */

#include "sopwith.h"
#include "gfx.h"

/* Half row, then the bit within it, as the hardware reports them */
#define ROW_CAPS 0                      /* CAPS Z X C V */
#define ROW_A    1                      /* A S D F G     */
#define ROW_Q    2                      /* Q W E R T     */
#define ROW_1    3                      /* 1 2 3 4 5     */
#define ROW_P    5                      /* P O I U Y     */
#define ROW_ENT  6                      /* ENTER L K J H */
#define ROW_SPC  7                      /* SPACE SS M N B */

#define KEY(row, bit) (((row) << 3) | (bit))

#define K_Q      KEY(ROW_Q, 0)
#define K_A      KEY(ROW_A, 0)
#define K_F      KEY(ROW_A, 3)
#define K_P      KEY(ROW_P, 0)
#define K_O      KEY(ROW_P, 1)
#define K_SPACE  KEY(ROW_SPC, 0)
#define K_B      KEY(ROW_SPC, 4)
#define K_M      KEY(ROW_SPC, 2)
#define K_H      KEY(ROW_ENT, 4)
#define K_1      KEY(ROW_1, 0)
#define K_N      KEY(ROW_SPC, 3)
#define K_E      KEY(ROW_Q, 2)
#define K_C      KEY(ROW_CAPS, 3)

/* Kempston, as the interface reports it */
#define JOY_RIGHT 0x01
#define JOY_LEFT  0x02
#define JOY_DOWN  0x04
#define JOY_UP    0x08
#define JOY_FIRE  0x10

static uint8_t rows[8];

static bool_t down(uint8_t k)
{
    return (rows[k >> 3] & (1 << (k & 7))) != 0;
}

uint16_t getgamekeys(void)
{
    static bool_t sound_was_down;
    uint16_t key = 0;
    uint8_t joy;

    key_read(rows);

    if (down(K_Q))     key |= K_FLAPU;
    if (down(K_A))     key |= K_FLAPD;
    if (down(K_P))     key |= K_ACCEL;
    if (down(K_O))     key |= K_DEACC;
    if (down(K_F))     key |= K_FLIP;
    if (down(K_SPACE)) key |= K_SHOT;
    if (down(K_B))     key |= K_BOMB;
    if (down(K_H))     key |= K_HOME;
    if (down(K_1))     key |= K_BREAK;

    /*
     * The stick flies and fires; flip, bomb, home and sound stay on the keys,
     * there being one button to go round. Throttle sits on left and right
     * because a plane's throttle is not a direction anyone expects to steer
     * with, and up and down are wanted for the stick itself.
     */
    joy = (uint8_t)joy_read();
    if (joy & JOY_UP)    key |= K_FLAPU;
    if (joy & JOY_DOWN)  key |= K_FLAPD;
    if (joy & JOY_RIGHT) key |= K_ACCEL;
    if (joy & JOY_LEFT)  key |= K_DEACC;
    if (joy & JOY_FIRE)  key |= K_SHOT;

    /* Sound toggles on the press, not for as long as the key is held */
    if (down(K_M)) {
        if (!sound_was_down) {
            soundflg = !soundflg;
            sound_was_down = TRUE;
        }
    } else {
        sound_was_down = FALSE;
    }

    return key;
}

void waitnokey(void)
{
    uint8_t i, any;

    do {
        key_read(rows);
        any = 0;
        for (i = 0; i < 8; i++) {
            any |= rows[i];
        }
        any |= (uint8_t)joy_read();
    } while (any);
}

/*
 * Wait for one of the menu keys and say which. Returns 'N', 'E' or 'C'; the
 * caller decides what those mean. The joystick's button picks the novice
 * game, so a stick alone can start one, and starts it on the gentler setting.
 */
uint8_t waitkey(void)
{
    for (;;) {
        key_read(rows);
        if (down(K_N)) return 'N';
        if (down(K_E)) return 'E';
        if (down(K_C)) return 'C';
        if (joy_read() & JOY_FIRE) return 'N';
    }
}
