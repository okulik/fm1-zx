/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * ZX Sopwith - the object pool and its two lists
 *
 * Objects live in a fixed array rather than the heap: the original callocs
 * whatever it needs and there is no room for that here, so allocobj() hands
 * out slots from a free list and returns NULL when they run out. Every caller
 * already copes with a refusal, because the DOS version could refuse too.
 *
 * Each object sits on two lists at once. One is creation order, walked when
 * everything has to move or be drawn. The other is sorted by X and is what
 * makes collision detection affordable: objects can only collide with the few
 * neighbours within a sprite's width of them, so the sweep stops as soon as
 * it passes the right hand edge instead of testing every pair.
 */

#include "sopwith.h"

static obj_t  objpool[MAX_OBJS];
static obj_t *objfree;
static obj_t *deltop, *delbot;

obj_t *objtop, *objbot;
obj_t  topobj, botobj;

int16_t imin(int16_t a, int16_t b) { return a < b ? a : b; }
int16_t imax(int16_t a, int16_t b) { return a > b ? a : b; }
int16_t iabs(int16_t a) { return a < 0 ? -a : a; }

bool_t PlaneIsKilled(uint8_t state)
{
    return state != FLYING && state != STALLED;
}

bool_t PlaneIsStalled(uint8_t state)
{
    return state == STALLED;
}

void initobjs(void)
{
    uint8_t i;

    for (i = 0; i < MAX_OBJS - 1; i++) {
        objpool[i].next = &objpool[i + 1];
    }
    objpool[MAX_OBJS - 1].next = NULL;
    objfree = &objpool[0];

    topobj.xnext = &botobj;
    botobj.xprev = &topobj;
    topobj.xprev = NULL;
    botobj.xnext = NULL;
    topobj.x = -32767;
    botobj.x = 32767;
    topobj.sym = botobj.sym = NULL;

    objtop = objbot = NULL;
    deltop = delbot = NULL;
}

obj_t *allocobj(void)
{
    obj_t *ob = objfree;
    uint8_t i;

    if (ob == NULL) {
        return NULL;
    }
    objfree = ob->next;

    for (i = 0; i < sizeof(obj_t); i++) {
        ((uint8_t *)ob)[i] = 0;
    }

    ob->prev = objbot;
    if (objbot != NULL) {
        objbot->next = ob;
    } else {
        objtop = ob;
    }
    objbot = ob;

    return ob;
}

/*
 * Freed objects are parked rather than returned straight away: the move loop
 * is walking the list when things die, and reusing a slot mid-sweep would
 * hand the same object to two different movement functions in one tic.
 */
void deallobj(obj_t *ob)
{
    obj_t *o;

    deletex(ob);

    o = ob->prev;
    if (o != NULL) {
        o->next = ob->next;
    } else {
        objtop = ob->next;
    }

    o = ob->next;
    if (o != NULL) {
        o->prev = ob->prev;
    } else {
        objbot = ob->prev;
    }

    ob->next = NULL;
    ob->prev = NULL;
    if (delbot != NULL) {
        delbot->next = ob;
    } else {
        deltop = ob;
    }
    delbot = ob;
}

void reapobjs(void)
{
    if (deltop != NULL) {
        delbot->next = objfree;
        objfree = deltop;
        deltop = delbot = NULL;
    }
}

void insertx(obj_t *ob, obj_t *near)
{
    obj_t *os = near;
    int16_t obx = ob->x;

    if (obx < os->x) {
        while (os->xprev != NULL && obx < os->xprev->x) {
            os = os->xprev;
        }
        ob->xprev = os->xprev;
        ob->xnext = os;
    } else {
        while (os->xnext != NULL && obx > os->xnext->x) {
            os = os->xnext;
        }
        ob->xprev = os;
        ob->xnext = os->xnext;
    }

    if (ob->xprev != NULL) {
        ob->xprev->xnext = ob;
    }
    if (ob->xnext != NULL) {
        ob->xnext->xprev = ob;
    }
}

/* Unhook, returning a neighbour to start the next search from */
obj_t *deletex(obj_t *ob)
{
    obj_t *oldpos = &topobj;

    if (ob->xprev != NULL) {
        oldpos = ob->xprev;
        ob->xprev->xnext = ob->xnext;
    }
    if (ob->xnext != NULL) {
        oldpos = ob->xnext;
        ob->xnext->xprev = ob->xprev;
    }
    ob->xprev = NULL;
    ob->xnext = NULL;

    return oldpos;
}

void updateobjpos(obj_t *ob)
{
    if (ob->xprev == NULL && ob->xnext == NULL) {
        return;                         /* not on the list */
    }
    insertx(ob, deletex(ob));
}

void copyobj(obj_t *to, obj_t *from)
{
    *to = *from;
    to->xprev = to->xnext = NULL;
    to->prev = to->next = NULL;
}

/*
 * Advance by one tic. Position is whole pixels plus a byte of fraction and
 * velocity is 8.8, so a step is an add, an arithmetic shift and a mask; the
 * original carries 16.16 throughout and pays for a 32 bit add per axis.
 */
void movexy(obj_t *ob)
{
    int16_t t;

    t = ob->xf + ob->dx;
    ob->x += t >> 8;
    ob->xf = t & 0xFF;
    if (ob->x < 0) {
        ob->x = 0;
    } else if (ob->x > WORLD_W - 10) {
        ob->x = WORLD_W - 10;
    }

    t = ob->yf + ob->dy;
    ob->y += t >> 8;
    ob->yf = t & 0xFF;

    updateobjpos(ob);
}

void setdxdy(obj_t *ob, int16_t dx, int16_t dy)
{
    ob->dx = dx;
    ob->dy = dy;
}
