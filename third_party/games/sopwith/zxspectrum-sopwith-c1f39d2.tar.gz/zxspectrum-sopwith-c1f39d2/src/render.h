/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef RENDER_H
#define RENDER_H

/*
 * The two sides, in the colours the CGA original used. Attribute bytes:
 * FLASH(7) BRIGHT(6) PAPER(5-3) INK(2-0), on black paper throughout.
 */
#define ATTR_MINE   0x45                /* bright cyan    */
#define ATTR_THEIRS 0x43                /* bright magenta */

void minimap_invalidate(void);

#endif
