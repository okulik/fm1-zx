/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * ZX Sopwith - the computer pilot
 *
 * A port of swauto.c. The pilot works by simulating itself: three copies of
 * the plane, one for each way the stick could go, each moved a tic forward to
 * see which ends up nearest whatever it is chasing and none of which fly into
 * a hill. Shooting is decided the same way, by flying a copy of the bullet
 * ten tics ahead and seeing whether it arrives.
 *
 * Formation flying is gone. It only engages between planes whose patrol
 * stretches overlap, and no two planes on the original map are set up that
 * way, so on the one map this port ships it never ran at all.
 */

#include "sopwith.h"

static int16_t courseadj;

int16_t range(int16_t x, int16_t y, int16_t ax, int16_t ay)
{
    int16_t dx, dy, t;

    dy = iabs(y - ay);
    dy += dy >> 1;
    dx = iabs(x - ax);

    if (dx < 125 && dy < 125) {
        return dx * dx + dy * dy;
    }

    if (dx < dy) {
        t = dx; dx = dy; dy = t;
    }

    /* Too far for a square; a negative answer still orders correctly */
    return -((7 * dx + (dy << 2)) >> 3);
}

/*
 * Would a bullet fired now hit? Returns 0 for no, 1 for a close shot and 2
 * for one far enough out that it is worth taking.
 */
static uint8_t shoot(obj_t *obt, obj_t *obs)
{
    static obj_t obsp, obtsp;
    int16_t nspeed, nangle, rprev, r;
    uint8_t i;

    copyobj(&obsp, obs);
    copyobj(&obtsp, obt);

    nspeed = obsp.speed + BULSPEED;
    setdxdy(&obsp, nspeed * COS(obsp.angle), nspeed * SIN(obsp.angle));
    obsp.x += 8;
    obsp.y -= 8;

    nangle = obtsp.angle;
    nspeed = obtsp.speed;
    rprev = NEAR;

    for (i = 0; i < BULLIFE; i++) {
        movexy(&obsp);

        if (obtsp.state == FLYING && obtsp.flaps) {
            if (obtsp.orient) {
                nangle -= obtsp.flaps;
            } else {
                nangle += obtsp.flaps;
            }
            nangle = (nangle + ANGLES) & (ANGLES - 1);
            setdxdy(&obtsp, nspeed * COS(nangle), nspeed * SIN(nangle));
        }

        movexy(&obtsp);

        r = range(obsp.x, obsp.y, obtsp.x, obtsp.y);
        if (r < 0 || r > rprev) {
            return 0;                   /* already going away again */
        }
        if (in_range(obtsp.x, obsp.x, obtsp.x + 15)
         && in_range(obtsp.y - 15, obsp.y, obtsp.y)) {
            return i > (BULLIFE / 3) ? 2 : 1;
        }
    }

    return 0;
}

static bool_t WithinHomeRange(obj_t *ob, int16_t x, int16_t y)
{
    return iabs(x - ob->orig->x) < HOME && iabs(y - ob->orig_y) < HOME;
}

/*
 * Is aiming here going to end in a hillside or a rooftop? Expressed as the
 * speed we are closing on the ground rather than a fixed height, so it holds
 * at the much greater speeds of the later levels.
 */
static bool_t tstcrash2(obj_t *ob, int16_t x, int16_t y, int16_t alt, int16_t dy)
{
    obj_t *obt;
    int16_t xl, xr, yt;
    uint8_t lookahead = 3;

    if (alt > 50) {
        return FALSE;
    }

    /*
     * On the last hop home one tic of lookahead is enough. With three, a fast
     * plane decides every descent is fatal and circles its own runway.
     */
    if ((ob->flags & OF_HOME) && WithinHomeRange(ob, x, y)) {
        lookahead = 1;
    }

    if (alt + ((dy * lookahead) >> 8) < 8) {
        return TRUE;
    }

    xl = clamp_min(x - 32, ob->x - 32 - gmaxspeed);
    xr = clamp_max(x + 32, ob->x + 32 + gmaxspeed);

    obt = ob;
    while (obt->xprev != NULL && obt->xprev->x >= xl) {
        obt = obt->xprev;
    }

    for (; obt->xnext != NULL; obt = obt->xnext) {
        if ((obt->type != TARGET && obt->type != OX) || obt->x < xl) {
            continue;
        }
        if (obt->x > xr) {
            return FALSE;
        }
        yt = obt->y + (obt->state == STANDING ? 16 : 8);
        if (y <= yt) {
            return TRUE;
        }
    }

    return FALSE;
}

int16_t aim(obj_t *ob, int16_t ax, int16_t ay, obj_t *obt, bool_t longway)
{
    static const int8_t cflaps[3] = { 0, -1, 1 };
    static int16_t crange[3], calt[3];
    static bool_t ccrash[3];
    static obj_t obs;

    int16_t r, rmin, x, y, dx, dy;
    int16_t nangle, nspeed;
    uint8_t i, n = 0;

    if (PlaneIsStalled(ob->state) && ob->angle != (3 * ANGLES / 4)) {
        ob->flaps = -1;
        ob->accel = MAX_THROTTLE;
        return 0;
    }

    x = ob->x;
    y = ob->y;
    dx = x - ax;

    if (iabs(dx) <= 160) {
        if (!longway) {
            ob->hitcount = 0;
        }
    } else {
        int16_t height;

        /* Already heading the right way: climb or dive to line up instead */
        if (ob->dx && (dx < 0) == (ob->dx < 0)) {
            if (!ob->hitcount) {
                ob->hitcount = (y > (MAX_Y - 50)) ? 2 : 1;
            }
            return aim(ob, x, ob->hitcount == 1 ? (y + 25) : (y - 25),
                       NULL, TRUE);
        }
        ob->hitcount = 0;
        height = clamp_max(y + 100, MAX_Y - 50 - courseadj);
        return aim(ob, x + (dx < 0 ? 150 : -150), height, NULL, TRUE);
    }

    /* Creep the last few pixels rather than orbiting them */
    if (ob->speed) {
        dy = y - ay;
        if (dy != 0 && iabs(dy) < 6) {
            y += dy < 0 ? 1 : -1;
            ob->y = y;
        } else if (dx != 0 && iabs(dx) < 6) {
            x += dx < 0 ? 1 : -1;
            ob->x = x;
            updateobjpos(ob);
        }
    }

    copyobj(&obs, ob);

    nspeed = obs.speed + 1;
    if (nspeed > gmaxspeed) {
        nspeed = gmaxspeed;
    } else if (nspeed < gminspeed) {
        nspeed = gminspeed;
    }

    for (i = 0; i < 3; i++) {
        nangle = (obs.angle + (obs.orient ? -cflaps[i] : cflaps[i]) + ANGLES)
               & (ANGLES - 1);
        setdxdy(&obs, nspeed * COS(nangle), nspeed * SIN(nangle));
        movexy(&obs);
        crange[i] = range(obs.x, obs.y, ax, ay);
        calt[i] = obs.y - (int16_t)ground[obs.x + 8];
        ccrash[i] = tstcrash2(ob, obs.x, obs.y, calt[i],
                              nspeed * SIN(nangle));
        copyobj(&obs, ob);
    }

    if (obt != NULL && shoot(obt, &obs)) {
        ob->flags |= OF_FIRING;
        ob->target = obt;
    }

    rmin = 32767;
    for (i = 0; i < 3; i++) {
        r = crange[i];
        if (r >= 0 && r < rmin && !ccrash[i]) {
            rmin = r;
            n = i;
        }
    }

    if (rmin == 32767) {
        /* Nothing in square range; fall back on the coarse estimate */
        rmin = -32767;
        for (i = 0; i < 3; i++) {
            r = crange[i];
            if (r < 0 && r > rmin && !ccrash[i]) {
                rmin = r;
                n = i;
            }
        }
    }

    if (ob->speed < gminspeed) {
        ob->accel = MAX_THROTTLE;
    }

    if (rmin == -32767) {
        /* Every option ends in a hill: throttle back and take the highest */
        if (ob->accel) {
            ob->accel--;
        }
        n = 0;
        dy = calt[0];
        if (calt[1] > dy) {
            dy = calt[1];
            n = 1;
        }
        if (calt[2] > dy) {
            n = 2;
        }
    } else if (ob->accel < MAX_THROTTLE) {
        ob->accel++;
    }

    ob->flaps = cflaps[n];
    if (!ob->flaps && ob->speed) {
        ob->orient = ob->dx < 0;
    }

    return 0;
}

int16_t gohome(obj_t *ob)
{
    if (ob->flags & OF_ATHOME) {
        return 0;
    }

    if (WithinHomeRange(ob, ob->x, ob->y)) {
        if (ob->flags & OF_COMPUTER) {
            initcomp(ob, ob->orig);
        } else {
            initplyr(ob, ob->orig);
            initdisp();
        }
        return 0;
    }

    return aim(ob, ob->orig->x, ob->orig_y, NULL, FALSE);
}

static void cruise(obj_t *ob)
{
    aim(ob,
        courseadj + clamp_range(WORLD_W / 3, ob->orig->x, 2 * WORLD_W / 3),
        MAX_Y - 50 - (courseadj >> 1), NULL, FALSE);
}

static void attack(obj_t *obp, obj_t *ob)
{
    if (ob->speed) {
        /* Aim for a point behind the target, so as to arrive on its tail */
        aim(obp,
            ob->x - ((CLOSE * COS(ob->angle)) >> 8),
            ob->y - ((CLOSE * SIN(ob->angle)) >> 8), ob, FALSE);
    } else {
        aim(obp, ob->x, ob->y + 4, ob, FALSE);
    }
}

void swauto(obj_t *ob)
{
    /* The course wander, shared by every path out of here */
    courseadj = ((countmove & 0x1F) < 16) << 4;

    if (ob->target != NULL) {
        attack(ob, ob->target);
    } else if (!(ob->flags & OF_ATHOME)) {
        cruise(ob);
    }

    ob->target = NULL;
}
