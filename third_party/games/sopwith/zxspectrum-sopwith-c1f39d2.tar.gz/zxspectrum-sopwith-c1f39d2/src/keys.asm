;
; Copyright (C) 2026 Neil Rackett
; SPDX-License-Identifier: GPL-3.0-or-later
;
; ZX Sopwith - reading the keyboard
;
; Flying needs several keys at once - throttle, stick and trigger together -
; which the ROM's one-key-at-a-time reader cannot report, so all eight half
; rows are read directly and the game tests bits.
;

        SECTION code_user

        PUBLIC  _key_read
        PUBLIC  _joy_read
        PUBLIC  _sys_init

; ---------------------------------------------------------------------------
; void sys_init(void)
;
; The game runs with interrupts off, from here to the end.
;
; The 48K ROM's handler reaches the system variables through IY while it scans
; the keyboard, so letting it run means holding IY at $5C3A for the whole life
; of the program. No C compiler on this toolchain will do that: the linked
; binary contains three dozen `ld iy,nn` and seven `add iy,sp`, the latter
; being frame pointer setup, and choosing the library variant that supposedly
; leaves IY free changes none of it. The handler then writes its keyboard
; state wherever IY happens to point, which corrupts whatever is there - and
; it corrupts it only while a key is held, so it looks like a bug in whatever
; that key does.
;
; Nothing else wanted the interrupt. The keyboard is read directly, the frame
; counter it maintained was only ever used to hold the game to ten frames a
; second, and the game does not reach ten. If it ever does, the answer is an
; IM 2 handler of our own - a 257 byte vector table and a counter - not this
; one back again.
; ---------------------------------------------------------------------------
_sys_init:
        di
        ret

; ---------------------------------------------------------------------------
; uint16_t joy_read(void)
;
; Kempston, on port $1F: bits 0 to 4 are right, left, down, up and fire,
; active high. With no interface fitted the port floats and returns whatever
; the ULA last saw, so a reading with any of the top three bits set cannot
; have come from a joystick and is thrown away. That is the usual test, and it
; means an unattached machine sees a steady zero rather than phantom input.
; ---------------------------------------------------------------------------
_joy_read:
        ld      bc,$001F
        in      a,(c)
        ld      e,a
        ld      h,0
        ld      l,0
        and     $E0
        ret     nz
        ld      a,e
        and     $1F
        ld      l,a
        ret

; ---------------------------------------------------------------------------
; void key_read(uint8_t *dst)
;
; Fills eight bytes, one per half row, in the order the address lines select
; them: CAPS-V, A-G, Q-T, 1-5, 0-6, P-Y, ENTER-H, SPACE-B. A set bit means the
; key is down, which is the opposite of what the hardware returns.
; ---------------------------------------------------------------------------
_key_read:
        ld      hl,2
        add     hl,sp
        ld      e,(hl)
        inc     hl
        ld      d,(hl)                  ; DE = destination
        ld      c,$FE
        ld      b,$FE
        ld      l,8
kr_loop:
        in      a,(c)
        cpl
        and     $1F
        ld      (de),a
        inc     de
        rlc     b
        dec     l
        jr      nz,kr_loop
        ret
