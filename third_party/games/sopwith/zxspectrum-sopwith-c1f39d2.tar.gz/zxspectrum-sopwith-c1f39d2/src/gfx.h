/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * The assembly drawing routines in gfx.asm. Every argument is 16 bits wide so
 * that the offsets the assembler reads off the stack stay regular.
 */

#ifndef GFX_H
#define GFX_H

#include <stdint.h>

/* A frame is copied from the start of whichever third it was drawn in */
#define GFX_THIRD   2048

void gfx_clear(uint16_t offset);
void gfx_show(uint16_t offset);
void gfx_sprite(int16_t sx, int16_t sy, const uint8_t *data, uint16_t rows);
void gfx_pixel(int16_t sx, int16_t sy);
void gfx_char(uint16_t cx, uint16_t cy, uint16_t ch);
void gfx_text(uint16_t cx, uint16_t cy, const char *s);
void gfx_hline(uint16_t row);
void gfx_ground(const uint8_t *heights);
void gfx_border(uint16_t colour);
void gfx_attr(uint16_t cx, uint16_t cy, uint16_t w, uint16_t h, uint16_t a);
void gfx_attrrow(uint16_t row, const uint8_t *src);
void gfx_blitmap(const uint8_t *src, uint16_t row, uint16_t rows,
                 uint16_t col, uint16_t bytes);

/* The highest world Y the last gfx_ground() call reached */
extern uint8_t gnd_top;

/* keys.asm */
void     key_read(uint8_t *dst);
uint16_t joy_read(void);
void     sys_init(void);

/* sound.asm */
void snd_tone(uint16_t pitch, uint16_t cycles);
void snd_noise(uint16_t seed, uint16_t cycles);

#endif
