/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * ZX Sopwith - choosing what to play
 *
 * The PC version keeps a tone running all the time and bends it with the
 * engine, because its speaker has a timer behind it that holds a pitch on its
 * own. The Spectrum's does not: every edge is a processor instruction, so a
 * continuous engine note would mean a continuous loop and no game underneath.
 *
 * So the sound is event driven instead. Anything that happens during a tic
 * asks for an effect, the loudest request wins - the same priority idea the
 * original uses to pick between competing sounds - and it is played once,
 * after the frame has been drawn, in a few thousand cycles.
 */

#include "sopwith.h"
#include "gfx.h"

#define SND_NONE 0xFF

static uint8_t pending = SND_NONE;

void sfx(uint8_t which)
{
    if (which < pending) {
        pending = which;
    }
}

void sfx_frame(void)
{
    uint8_t s = pending;

    pending = SND_NONE;

    if (!soundflg || s == SND_NONE) {
        return;
    }

    switch (s) {
    case SND_EXPLODE: snd_noise(6, 90);  break;
    case SND_CRASH:   snd_noise(20, 70); break;
    case SND_BOMB:    snd_tone(60, 24);  break;
    case SND_HIT:     snd_tone(110, 20); break;
    case SND_SHOT:    snd_tone(14, 18);  break;
    case SND_MENU:    snd_tone(40, 16);  break;
    default: break;
    }
}
