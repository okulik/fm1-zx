/*
 * Copyright (C) 2026 Neil Rackett
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * ZX Sopwith - object creation and movement
 *
 * A port of swinit.c and swmove.c. The flight model is unchanged: the same
 * sixteen angles, the same gravity table, the same four-tic throttle, so a
 * plane handles exactly as it does on the PC. What has changed is the
 * arithmetic underneath it, from 16.16 fixed point to whole pixels plus a
 * byte of fraction, which halves the work per object per tic.
 */

#include "sopwith.h"
#include "gfx.h"

/* Where the plane sits in the sky, by angle: the original's gravity model */
static const int8_t gravity[ANGLES] = {
    0, -1, -2, -3, -4, -3, -2, -1,
    0,  1,  2,  3,  4,  3,  2,  1
};

const int16_t sintab[ANGLES] = {
    0, 98, 181, 237,
    256, 237, 181, 98,
    0, -98, -181, -237,
    -256, -237, -181, -98
};

uint8_t  playmode;
uint8_t  gamenum;
int8_t   gmaxspeed, gminspeed;
int16_t  targrnge;
int16_t  numtarg[3];
uint16_t countmove;
int16_t  displx;
int16_t  endcount;
int16_t  score;
int16_t  hiscore;
bool_t   soundflg = TRUE;
bool_t   restart_flag;
bool_t   compplane, plyrplane;
uint8_t  endstat;
uint16_t explseed = 7491;

obj_t   *planes[MAX_PLANES];
uint8_t  num_planes;
obj_t   *consoleplayer;


static bool_t movepln(obj_t *ob);
static void   interpret(obj_t *ob, uint16_t key);

/* --- helpers ---------------------------------------------------------- */

/*
 * Nudge a velocity one whole pixel per tic towards nothing. The original can
 * write ++dx because its dx is a whole number of pixels; here the fraction
 * has to be caught, or a plane drifting at less than a pixel a tic would be
 * flipped into drifting the other way.
 */
static int16_t towards_zero(int16_t v)
{
    if (v > FX(1)) {
        return v - FX(1);
    }
    if (v < -FX(1)) {
        return v + FX(1);
    }
    return 0;
}

static uint8_t symangle(obj_t *ob)
{
    if (ob->dx == 0) {
        return ob->dy > 0 ? 2 : 6;
    }
    if (ob->dx > 0) {
        if (ob->dy < 0) {
            return 7;
        }
        return ob->dy > 0 ? 1 : 0;
    }
    if (ob->dy < 0) {
        return 5;
    }
    return ob->dy > 0 ? 3 : 4;
}

/* --- initialisation --------------------------------------------------- */

obj_t *initpln(obj_t *obp, const orig_ob_t *orig)
{
    obj_t *ob;
    int16_t x, height, maxx;

    if (obp == NULL) {
        ob = allocobj();
        if (ob == NULL) {
            return NULL;
        }
        ob->orig = orig;
        planes[num_planes++] = ob;
    } else {
        ob = obp;
    }

    ob->type = PLANE;
    ob->x = ob->orig->x;
    maxx = ob->x + 20;
    height = 0;
    for (x = ob->x; x <= maxx; x++) {
        height = imax(height, ground[x]);
    }
    ob->y = height + 13;
    ob->orig_y = (uint8_t)ob->y;

    ob->xf = ob->yf = 0;
    ob->dx = ob->dy = 0;
    ob->speed = ob->flaps = ob->accel = 0;
    ob->hitcount = ob->bdelay = 0;
    ob->orient = ob->orig->orient;
    ob->angle = ob->orient ? (ANGLES / 2) : 0;
    ob->target = NULL;
    ob->sym = &spr_plane[ob->orient * 16];
    ob->flags = (ob->flags & OF_COMPUTER) | OF_ATHOME | OF_ONMAP;

    if (obp == NULL || ob->state == CRASHED) {
        ob->rounds = MAXROUNDS;
        ob->bombs = MAXBOMBS;
        ob->life = MAXFUEL;
    }

    if (obp == NULL) {
        ob->endsts = PLAYING;
        insertx(ob, &topobj);
    } else {
        insertx(ob, deletex(ob));
    }

    ob->state = FLYING;

    return ob;
}

void initplyr(obj_t *obp, const orig_ob_t *orig)
{
    obj_t *ob = initpln(obp, orig);

    if (ob == NULL) {
        return;
    }
    if (obp == NULL) {
        ob->faction = FACTION_PLAYER;
        consoleplayer = ob;
        endcount = 0;
    }
}

void initcomp(obj_t *obp, const orig_ob_t *orig)
{
    obj_t *ob = initpln(obp, orig);

    if (ob == NULL) {
        return;
    }
    if (obp == NULL) {
        ob->flags |= OF_COMPUTER;
        ob->faction = FACTION_ENEMY;
    }

    /* Only the "versus computer" mode puts enemy planes in the air */
    if (playmode != PLAYMODE_COMPUTER) {
        ob->state = FINISHED;
        ob->flags &= ~OF_ONMAP;
        deletex(ob);
    }
}

/*
 * When a target fires, its first bullet can start inside its own sprite, and
 * on the PC a hangar could shoot down its own flag. Nudge the bullet clear
 * before it is let go.
 */
static void adjustbullet(obj_t *bullet, obj_t *src)
{
    obj_t next_bullet, next_src;
    uint8_t tries;

    copyobj(&next_src, src);
    movexy(&next_src);

    for (tries = 0; tries < 8; tries++) {
        copyobj(&next_bullet, bullet);
        movexy(&next_bullet);

        if (!CollisionTest(&next_bullet, &next_src)) {
            return;
        }

        bullet->x += bullet->dx < 0 ? -2 : 2;
        bullet->y += bullet->dy < 0 ? -2 : 2;
    }
}

static int16_t isrange(int16_t x, int16_t y, int16_t ax, int16_t ay)
{
    int16_t dx, dy, t;

    dy = iabs(y - ay);
    dy += dy >> 1;
    dx = iabs(x - ax);

    if (dx > 100 || dy > 100) {
        return -1;
    }
    if (dx < dy) {
        t = dx; dx = dy; dy = t;
    }
    return (7 * dx + 4 * dy) >> 3;
}

void initshot(obj_t *obo, obj_t *targ)
{
    obj_t *ob;
    int16_t dx, dy, r, bspeed, x, y;

    if (targ == NULL && !compplane && obo->rounds == 0) {
        return;
    }

    ob = allocobj();
    if (ob == NULL) {
        return;
    }

    if (playmode != PLAYMODE_NOVICE && obo->rounds > 0) {
        obo->rounds--;
    }

    bspeed = BULSPEED + gamenum;

    if (targ != NULL) {
        x = targ->x + ((targ->dx * 4) >> 8);
        y = targ->y + ((targ->dy * 4) >> 8);
        dx = x - obo->x;
        dy = y - obo->y;

        r = isrange(x, y, obo->x, obo->y);
        if (r < 1) {
            deallobj(ob);
            return;
        }
        ob->dx = (int16_t)(((int32_t)dx * bspeed * 256) / r);
        ob->dy = (int16_t)(((int32_t)dy * bspeed * 256) / r);
    } else {
        int16_t nspeed = obo->speed + bspeed;
        setdxdy(ob, nspeed * COS(obo->angle), nspeed * SIN(obo->angle));
    }

    ob->type = SHOT;
    ob->x = obo->x + (obo->sym->w >> 1);
    ob->y = obo->y - (obo->sym->h >> 1);
    ob->xf = obo->xf;
    ob->yf = obo->yf;
    ob->life = BULLIFE;
    ob->faction = obo->faction;
    ob->sym = NULL;                     /* a bullet is one pixel */

    adjustbullet(ob, obo);
    insertx(ob, obo);
    sfx(SND_SHOT);
}

void initbomb(obj_t *obo)
{
    obj_t *ob;
    uint8_t angle;

    if ((!compplane && obo->bombs == 0) || obo->bdelay != 0) {
        return;
    }

    ob = allocobj();
    if (ob == NULL) {
        return;
    }

    if (playmode != PLAYMODE_NOVICE && obo->bombs > 0) {
        obo->bombs--;
    }
    obo->bdelay = 10;

    ob->type = BOMB;
    ob->state = FALLING;
    ob->dx = obo->dx;
    ob->dy = obo->dy;
    ob->flags = OF_ONMAP;

    if (obo->orient) {
        angle = (obo->angle + (ANGLES / 4)) & (ANGLES - 1);
    } else {
        angle = (obo->angle + (3 * ANGLES / 4)) & (ANGLES - 1);
    }

    ob->x = obo->x + ((COS(angle) * 10) >> 8) + 4;
    ob->y = obo->y + ((SIN(angle) * 10) >> 8) - 4;
    ob->life = BOMBLIFE;
    ob->faction = obo->faction;
    ob->sym = &spr_bomb[0];

    insertx(ob, obo);
    sfx(SND_BOMB);
}

void initexpl(obj_t *obo, bool_t small)
{
    obj_t *ob;
    int16_t i, obox, oboy, obodx, obody;
    uint8_t ic, speed, obotype, orient;
    bool_t mansym;

    obox = obo->x + (obo->sym == NULL ? 0 : obo->sym->w >> 1);
    oboy = obo->y + (obo->sym == NULL ? 0 : obo->sym->h >> 1);
    obodx = obo->dx >> 2;
    obody = obo->dy >> 2;
    obotype = obo->type;

    if (obotype == TARGET && obo->orient == 2) {
        /* Oil tanks go up properly */
        ic = 1;
        speed = gminspeed + 4;
    } else {
        speed = gminspeed >> ((explseed & 7) != 7);
        if (small) {
            ic = 6;
        } else {
            ic = 2;
        }
    }

    mansym = obotype == PLANE && obo->state == FLYING;

    for (i = 1; i <= 15; i += ic) {
        ob = allocobj();
        if (ob == NULL) {
            return;
        }

        ob->type = EXPLOSION;
        setdxdy(ob, COS(i) * speed, SIN(i) * speed);
        ob->dx += obodx;
        ob->dy += obody;

        ob->x = obox + (ob->dx >> 8);
        ob->y = oboy + (ob->dy >> 8);

        explseed = explseed * (uint16_t)(ob->x * ob->y) + 7491;
        if (explseed == 0) {
            explseed = 29777;
        }

        ob->life = EXPLLIFE;
        orient = (explseed & 0x01C0) >> 6;
        ob->orient = orient;

        /*
         * One fragment of a shot down plane is the pilot, thrown clear. The
         * original picks him out of the debris the same way.
         */
        if (mansym && (orient == 0 || orient == 7)) {
            ob->orient = 0;
            mansym = FALSE;
            ob->dx = obodx;
            ob->dy = -FX(1) * gminspeed;
        }

        ob->faction = obo->faction;
        ob->sym = &spr_debris[ob->orient];

        insertx(ob, obo);
    }
}

void initsmok(obj_t *obo)
{
    obj_t *ob = allocobj();

    if (ob == NULL) {
        return;
    }

    ob->type = SMOKE;
    ob->x = obo->x + 8;
    ob->y = obo->y - 8;
    ob->dx = obo->dx;
    ob->dy = obo->dy;
    ob->life = SMOKELIFE;
    ob->target = obo;                   /* smoke remembers its plane here */
    ob->faction = obo->faction;
    ob->sym = NULL;
}

void initbird(obj_t *obo, uint8_t i)
{
    static const int8_t ibx[8]  = {  8,  3,  0,  6,  7, 14, 10, 12 };
    static const int8_t iby[8]  = { 16,  1,  8,  3, 12, 10,  7, 14 };
    static const int8_t ibdx[8] = { -2,  2, -3,  3, -1,  1,  0,  0 };
    static const int8_t ibdy[8] = { -1, -2, -1, -2, -1, -2, -1, -2 };

    obj_t *ob = allocobj();

    if (ob == NULL) {
        return;
    }

    ob->type = BIRD;
    ob->x = obo->x + ibx[i];
    ob->y = obo->y - iby[i];
    ob->dx = FX(1) * ibdx[i];
    ob->dy = FX(1) * ibdy[i];
    ob->life = BIRDLIFE;
    ob->faction = FACTION_NONE;
    ob->sym = &spr_bird[0];

    insertx(ob, &topobj);
}

static obj_t *initflock(const orig_ob_t *orig)
{
    obj_t *ob = allocobj();

    if (ob == NULL) {
        return NULL;
    }

    ob->type = FLOCK;
    ob->state = FLYING;
    ob->x = orig->x;
    ob->y = MAX_Y - 1;
    ob->dx = ob->x < (WORLD_W / 2) ? FX(2) : FX(-2);
    ob->life = FLOCKLIFE;
    ob->faction = FACTION_NONE;
    ob->sym = &spr_flock[0];
    ob->flags = OF_ONMAP;

    return ob;
}

static obj_t *initox(const orig_ob_t *orig)
{
    obj_t *ob = allocobj();

    if (ob == NULL) {
        return NULL;
    }

    ob->type = OX;
    ob->state = STANDING;
    ob->x = orig->x;
    ob->y = ground[ob->x] + 16;
    ob->faction = FACTION_NONE;
    ob->sym = &spr_ox[0];

    return ob;
}

static obj_t *inittarget(const orig_ob_t *orig)
{
    obj_t *ob = allocobj();
    int16_t x, minh, maxh, aveh, maxx;

    if (ob == NULL) {
        return NULL;
    }

    ob->sym = &spr_target[orig->orient * 2 + orig->mirrored];
    ob->x = orig->x;
    maxx = ob->x + ob->sym->w - 1;
    minh = 999;
    maxh = 0;
    for (x = ob->x; x <= maxx; x++) {
        minh = imin(minh, ground[x]);
        maxh = imax(maxh, ground[x]);
    }

    aveh = (minh + maxh) >> 1;
    aveh = clamp_max(aveh, MAX_Y - ob->sym->h - 1);
    ob->y = aveh + ob->sym->h;

    /* Level the ground under it, so it does not float or sink */
    for (x = ob->x; x <= maxx; x++) {
        ground[x] = (uint8_t)aveh;
    }

    ob->type = TARGET;
    ob->state = STANDING;
    ob->orient = orig->orient;
    ob->faction = orig->faction;
    ob->flags = OF_ONMAP;
    numtarg[ob->faction]++;

    return ob;
}

/* --- level start ------------------------------------------------------ */

void swinitlevel(void)
{
    const orig_ob_t *orig;
    const orig_ob_t *player_ob = NULL;
    obj_t *ob;
    uint8_t i;

    initgrnd();
    initobjs();

    num_planes = 0;
    numtarg[0] = numtarg[1] = numtarg[2] = 0;
    countmove = 0;
    endcount = 0;
    endstat = PLAYING;

    for (i = 0; i < MAX_PLANES; i++) {
        planes[i] = NULL;
    }

    /* Buildings first: they flatten the ground, and planes stand on it */
    for (i = 0; i < level_num_objects; i++) {
        orig = &level_objects[i];
        ob = NULL;
        switch (orig->type) {
        case TARGET: ob = inittarget(orig); break;
        case OX:     ob = playmode == PLAYMODE_NOVICE ? NULL : initox(orig); break;
        case FLOCK:  ob = playmode == PLAYMODE_NOVICE ? NULL : initflock(orig); break;
        default:     continue;
        }
        if (ob != NULL) {
            ob->orig = orig;
            insertx(ob, &topobj);
            if (orig->type == FLOCK) {
                initbird(ob, 1);
            }
        }
    }

    for (i = 0; i < level_num_objects; i++) {
        if (level_objects[i].type == PLANE
         && level_objects[i].faction == FACTION_PLAYER) {
            player_ob = &level_objects[i];
            break;
        }
    }

    initplyr(NULL, player_ob);

    for (i = 0; i < level_num_objects; i++) {
        orig = &level_objects[i];
        if (orig->type == PLANE && orig->faction != FACTION_PLAYER) {
            initcomp(NULL, orig);
        }
    }

    gmaxspeed = MAX_SPEED + gamenum;
    gminspeed = MIN_SPEED + gamenum;

    targrnge = 150;
    if (gamenum < 6) {
        targrnge -= 15 * (6 - gamenum);
    }
    targrnge *= targrnge;

    initdisp();
}

void swrestart(void)
{
    if (consoleplayer->endsts == WINNER) {
        /* Points for every life still in hand, counted off one at a time */
        int16_t inc = 0;

        while (consoleplayer->crashcnt < MAXCRASH) {
            consoleplayer->crashcnt++;
            inc += 25;
            score += inc;
            swdisp();
        }
        gamenum++;
    } else {
        if (score > hiscore) {
            hiscore = score;
        }
        score = 0;
        gamenum = 0;
        playmode = PLAYMODE_UNSET;
    }

    restart_flag = TRUE;
}

/* --- the move loop ---------------------------------------------------- */

static bool_t moveshot(obj_t *ob)
{
    ob->life--;
    if (ob->life <= 0) {
        deallobj(ob);
        return FALSE;
    }

    movexy(ob);

    if (ob->x < 0 || ob->x >= WORLD_W
     || ob->y <= (int16_t)ground[ob->x] || ob->y >= MAX_Y) {
        deallobj(ob);
        return FALSE;
    }

    ob->sym = NULL;
    return TRUE;
}

static void adjustfall(obj_t *ob)
{
    ob->life--;
    if (ob->life <= 0) {
        if (ob->dy < 0) {
            ob->dx = towards_zero(ob->dx);
        }
        if (ob->dy > FX(-10)) {
            ob->dy -= FX(1);
        }
        ob->life = BOMBLIFE;
    }
}

static bool_t movebomb(obj_t *ob)
{
    if (ob->life < 0) {
        deallobj(ob);
        ob->state = FINISHED;
        return FALSE;
    }

    adjustfall(ob);
    movexy(ob);

    if (ob->y < 0 || ob->x < 0 || ob->x >= WORLD_W) {
        deallobj(ob);
        ob->state = FINISHED;
        return FALSE;
    }

    ob->sym = &spr_bomb[symangle(ob)];
    return ob->y < MAX_Y;
}

/*
 * Buildings run every tic like anything else, and there are two dozen of them,
 * so the common case - a building standing still on a peaceful first level -
 * gets out early. Its sprite was set when it was placed and does not change
 * until the moment it is hit.
 */
static bool_t movetarg(obj_t *ob)
{
    const sprite_t *oldsym;

    if (ob->hitcount > 0) {
        ob->hitcount--;
    }

    if (ob->state == STANDING) {
        if (gamenum > 0 && (gamenum > 1 || (countmove & 1))) {
            obj_t *plane = consoleplayer;
            /* Your own buildings do not shoot at you. The original reaches
               this through a search for an enemy plane, which skips its own
               faction; with one human pilot it is a single comparison. */
            if (ob->faction != plane->faction
             && !PlaneIsKilled(plane->state)
             && in_range(1, range(ob->x, ob->y, plane->x, plane->y),
                         targrnge - 1)) {
                initshot(ob, plane);
                ob->flags |= OF_FIRING;
            }
        }
        return TRUE;
    }

    oldsym = ob->sym;
    if (oldsym != &spr_targhit[ob->orig->mirrored]) {
        ob->sym = &spr_targhit[ob->orig->mirrored];
        /* A wreck is a different size; keep it centred and on the ground */
        ob->x += (oldsym->w - ob->sym->w) >> 1;
        ob->y -= oldsym->h - ob->sym->h;
    }

    return TRUE;
}

static bool_t moveexpl(obj_t *ob)
{
    if (ob->life < 0) {
        deallobj(ob);
        return FALSE;
    }

    ob->life--;
    if (ob->life <= 0) {
        if (ob->dy < 0) {
            ob->dx = towards_zero(ob->dx);
        }
        if (ob->orient) {
            if (ob->dy > FX(-10)) {
                ob->dy -= FX(1);
            }
        } else if (ob->dy > -FX(1) * gminspeed) {
            ob->dy -= FX(1);
        }
        ob->life = EXPLLIFE;
    }

    movexy(ob);

    if (ob->x < 0 || ob->x >= WORLD_W || ob->y <= (int16_t)ground[ob->x]) {
        deallobj(ob);
        return FALSE;
    }

    ob->hitcount++;
    ob->sym = &spr_debris[ob->orient];

    return ob->y < MAX_Y;
}

static bool_t movesmok(obj_t *ob)
{
    uint8_t planestate = ob->target->state;

    ob->life--;
    if (ob->life <= 0
     || (planestate != FALLING && planestate != CRASHED)) {
        deallobj(ob);
        return FALSE;
    }

    ob->sym = NULL;
    return TRUE;
}

static bool_t moveflck(obj_t *ob)
{
    if (ob->life == -1) {
        deallobj(ob);
        return FALSE;
    }

    ob->life--;
    if (ob->life <= 0) {
        ob->orient = !ob->orient;
        ob->life = FLOCKLIFE;
    }

    if (ob->x < ob->orig->territory_l) {
        ob->dx = iabs(ob->dx);
    } else if (ob->x > ob->orig->territory_r) {
        ob->dx = -iabs(ob->dx);
    }

    movexy(ob);
    ob->sym = &spr_flock[ob->orient];
    return TRUE;
}

/* Would a bird flying this way meet a hillside within twenty pixels? */
static bool_t checkwall(obj_t *ob, int16_t direction)
{
    int16_t check_x = ob->x;
    uint8_t cnt;

    for (cnt = 0; cnt < 20; cnt++) {
        if (check_x < 0 || check_x >= WORLD_W) {
            return TRUE;
        }
        if ((int16_t)ground[check_x] > ob->y + 10) {
            return TRUE;
        }
        check_x += direction < 0 ? -1 : 1;
    }
    return FALSE;
}

static bool_t movebird(obj_t *ob)
{
    if (ob->life == -1) {
        deallobj(ob);
        return FALSE;
    }

    if (ob->life == -2) {
        ob->dy = -ob->dy;
        ob->dx = FX(1) * ((int16_t)(countmove & 7) - 4);
        if (checkwall(ob, ob->dx)) {
            ob->dx = -ob->dx;
        }
        ob->life = BIRDLIFE;
    } else {
        ob->life--;
        if (ob->life <= 0) {
            ob->orient = !ob->orient;
            ob->life = BIRDLIFE;
        }
    }

    movexy(ob);
    ob->sym = &spr_bird[ob->orient];

    if (ob->x < 0 || ob->x >= WORLD_W
     || ob->y <= (int16_t)ground[ob->x] || ob->y >= MAX_Y) {
        ob->y -= ob->dy >> 8;
        ob->life = -2;
        return FALSE;
    }
    return TRUE;
}

static bool_t moveox(obj_t *ob)
{
    ob->sym = &spr_ox[ob->state != STANDING];
    return TRUE;
}

bool_t crashpln(obj_t *ob)
{
    if (ob->dx < 0) {
        ob->angle = (ob->angle + 2) & (ANGLES - 1);
    } else {
        ob->angle = (ob->angle + ANGLES - 2) & (ANGLES - 1);
    }

    ob->state = CRASHED;
    ob->flags &= ~OF_ATHOME;
    ob->dx = ob->dy = 0;
    ob->xf = ob->yf = 0;
    ob->speed = 0;

    /* Come down near your own field and you are back in the air sooner */
    ob->hitcount = (iabs(ob->orig->x - ob->x) < SAFERESET
                 && iabs(ob->orig_y - ob->y) < SAFERESET)
                 ? (MAXCRCOUNT * 2) : MAXCRCOUNT;

    return TRUE;
}

bool_t hitpln(obj_t *ob)
{
    ob->hitcount = FALLCOUNT;
    ob->state = FALLING;
    ob->flags &= ~OF_ATHOME;
    return TRUE;
}

static bool_t stallpln(obj_t *ob)
{
    ob->orient = 0;
    ob->dx = 0;
    ob->angle = 7 * ANGLES / 8;
    ob->speed = 0;
    ob->dy = 0;
    ob->hitcount = STALLCOUNT;
    ob->state = STALLED;
    ob->flags &= ~OF_ATHOME;
    return TRUE;
}

/*
 * Sitting on your own runway refills everything, slowly. The original runs
 * this through one counter-by-pointer helper, which here would mean widening
 * two byte-sized fields and copying them in and out; three lines of arithmetic
 * cost less and read the same.
 */
static void refuel(obj_t *ob)
{
    if (ob->life < MAXFUEL) {
        ob->life = clamp_max(ob->life + MAXFUEL / 100, MAXFUEL);
    }
    if (ob->rounds < MAXROUNDS) {
        ob->rounds = (uint8_t)clamp_max(ob->rounds + MAXROUNDS / 100,
                                        MAXROUNDS);
    }
    if (ob->bombs < MAXBOMBS && (countmove % 20) == 0) {
        ob->bombs++;
    }
}

/*
 * The heart of it: one plane, one tic. Straight from movepln() in swmove.c,
 * with the fixed point widened and the four sound callbacks folded into a
 * single request that the mixer picks the loudest of.
 */
static bool_t movepln(obj_t *ob)
{
    int16_t nangle, nspeed, limit;
    uint8_t state;
    bool_t stalled, update;

    state = ob->state;

    switch (state) {
    case FINISHED:
    case WAITING:
        return FALSE;

    case CRASHED:
        ob->hitcount--;
        break;

    case FALLING:
        ob->hitcount -= 2;
        if (ob->dy < 0 && ob->dx != 0) {
            if (ob->orient ^ (ob->dx < 0)) {
                ob->hitcount -= ob->flaps;
            } else {
                ob->hitcount += ob->flaps;
            }
        }

        if (ob->hitcount <= 0) {
            if (ob->dy < 0) {
                if (ob->dx != 0) {
                    ob->dx = towards_zero(ob->dx);
                } else {
                    ob->orient++;
                }
            }
            if (ob->dy > FX(-10)) {
                ob->dy -= FX(1);
            }
            ob->hitcount = FALLCOUNT;
        }
        ob->angle = symangle(ob) * 2;
        break;

    case STALLED:
        stalled = ob->angle != (3 * ANGLES / 4) || ob->speed < gminspeed;
        if (!stalled) {
            ob->state = state = FLYING;
        }
        goto controlled;

    case FLYING:
        stalled = ob->y >= MAX_Y;
        if (stalled) {
            if (playmode == PLAYMODE_NOVICE) {
                ob->angle = (3 * ANGLES / 4);
                stalled = FALSE;
            } else {
                stallpln(ob);
                state = ob->state;
            }
        }

    controlled:
        if (ob->flags & OF_GOINGSUN) {
            break;
        }

        if (ob->life <= 0 && !(ob->flags & OF_ATHOME)
         && !PlaneIsKilled(state)) {
            hitpln(ob);
            scorepln(ob);
            return movepln(ob);
        }

        if (ob->flags & OF_FIRING) {
            initshot(ob, NULL);
        }
        if (ob->flags & OF_BOMBING) {
            initbomb(ob);
        }

        nangle = ob->angle;
        nspeed = ob->speed;
        update = ob->flaps != 0;

        if (update) {
            if (ob->orient) {
                nangle -= ob->flaps;
            } else {
                nangle += ob->flaps;
            }
            nangle = (nangle + ANGLES) & (ANGLES - 1);
        }

        if ((countmove & 3) == 0) {
            if (!stalled && nspeed < gminspeed
             && playmode != PLAYMODE_NOVICE) {
                nspeed--;
                update = TRUE;
            } else {
                limit = gminspeed + ob->accel + gravity[nangle];
                if (nspeed < limit) {
                    nspeed++;
                    update = TRUE;
                } else if (nspeed > limit) {
                    nspeed--;
                    update = TRUE;
                }
            }
        }

        if (update) {
            if (ob->flags & OF_ATHOME) {
                nspeed = (ob->accel || ob->flaps) ? gminspeed : 0;
            } else if (nspeed <= 0 && !stalled) {
                if (playmode == PLAYMODE_NOVICE) {
                    nspeed = 1;
                } else {
                    stallpln(ob);
                    return movepln(ob);
                }
            }

            ob->speed = (int8_t)nspeed;
            ob->angle = (uint8_t)nangle;

            if (stalled) {
                ob->dx = 0;
                ob->dy = -FX(1) * nspeed;
            } else {
                setdxdy(ob, nspeed * COS(nangle), nspeed * SIN(nangle));
            }
        }

        if (stalled) {
            ob->hitcount--;
            if (ob->hitcount <= 0) {
                ob->orient = !ob->orient;
                ob->angle = ((3 * ANGLES / 2) - ob->angle) & (ANGLES - 1);
                ob->hitcount = STALLCOUNT;
            }
        }

        if (!compplane) {
            ob->life -= ob->speed;
        } else if (ob->life > 100) {
            ob->life -= ob->speed;
        }

        if (ob->speed) {
            ob->flags &= ~OF_ATHOME;
        }
        break;

    default:
        break;
    }

    /* Which way it is pointing, on the screen */
    if (ob->endsts == WINNER && (ob->flags & OF_GOINGSUN)) {
        ob->sym = &spr_planewin[clamp_range(0, endcount / 18, 3)];
    } else if (ob->state == FINISHED) {
        ob->sym = &spr_plane[0];
    } else if (ob->state == FALLING && ob->dx == 0 && ob->dy < 0) {
        ob->sym = &spr_planehit[ob->orient & 3];
    } else if (ob->orient) {
        ob->sym = &spr_plane[16 + ((ANGLES - ob->angle) & (ANGLES - 1))];
    } else {
        ob->sym = &spr_plane[ob->angle];
    }

    movexy(ob);

    if (ob->x < 0 || ob->x > WORLD_W - 16) {
        ob->x = clamp_range(0, ob->x, WORLD_W - 16);
        updateobjpos(ob);
    }

    if (ob->bdelay) {
        ob->bdelay--;
    }

    if (!compplane && (ob->flags & OF_ATHOME) && ob->state == FLYING) {
        refuel(ob);
    }

    if (in_range(0, ob->y, MAX_Y - 1)) {
        if (ob->state == FALLING) {
            initsmok(ob);
        }
        return plyrplane || ob->state < FINISHED;
    }

    return FALSE;
}

static void interpret(obj_t *ob, uint16_t key)
{
    uint8_t state = ob->state;

    ob->flaps = 0;
    ob->flags &= ~(OF_BOMBING | OF_FIRING);

    if (PlaneIsKilled(state) && state != FALLING) {
        return;
    }

    if (state != FALLING) {
        if (endstat) {
            if (endstat == LOSER && plyrplane) {
                gohome(ob);
            }
            return;
        }

        if (key & K_BREAK) {
            ob->life = QUIT;
            ob->flags &= ~OF_HOME;
            if (ob->flags & OF_ATHOME) {
                ob->state = CRASHED;
                ob->hitcount = 0;
            }
        }

        if ((key & K_HOME) && state == FLYING) {
            ob->flags |= OF_HOME;
        }
    }

    /* Any hand on the controls cancels the autopilot */
    if (key & (K_FLAPU | K_FLAPD | K_FLIP | K_DEACC | K_ACCEL)) {
        ob->flags &= ~OF_HOME;
    }

    if (key & K_FLAPU) {
        ob->flaps++;
    }
    if (key & K_FLAPD) {
        ob->flaps--;
    }

    /* No barrel rolls on the runway; the PC version let you and it looked odd */
    if ((key & K_FLIP) && !(ob->flags & OF_ATHOME)) {
        ob->orient = !ob->orient;
    }

    if (key & K_DEACC) {
        if (ob->accel) {
            ob->accel--;
        }
    }
    if (key & K_ACCEL) {
        if (ob->accel < MAX_THROTTLE) {
            ob->accel++;
        }
    }

    if ((key & K_SHOT) && state < FINISHED) {
        ob->flags |= OF_FIRING;
    }
    if ((key & K_BOMB) && state < FINISHED) {
        ob->flags |= OF_BOMBING;
    }

    if (ob->flags & OF_HOME) {
        gohome(ob);
    }
}

static bool_t moveplyr(obj_t *ob)
{
    uint16_t key;

    compplane = FALSE;
    plyrplane = TRUE;
    endstat = consoleplayer->endsts;

    if (endstat) {
        endcount--;
        if (endcount <= 0) {
            swrestart();
            return TRUE;
        }
    }

    key = getgamekeys();
    interpret(ob, key);

    if (ob->state == CRASHED && ob->hitcount <= 0) {
        ob->crashcnt++;

        if (endstat != WINNER
         && (ob->life <= QUIT || ob->crashcnt >= MAXCRASH)) {
            if (!endstat) {
                loser(ob);
            }
        } else {
            initplyr(ob, ob->orig);
            initdisp();
            if (endstat == WINNER) {
                winner(ob);
            }
        }
    }

    return movepln(ob);
}

/*
 * The computer's planes look for whoever is nearest and inside the stretch of
 * map they are responsible for. In single player that stretch is ignored, so
 * every enemy plane on the map comes after you.
 */
static void nearpln(obj_t *ob)
{
    uint8_t i;
    int16_t obx = ob->x;

    for (i = 0; i < num_planes; i++) {
        obj_t *obt = planes[i];

        if (obt == NULL || obt->faction == ob->faction
         || !(obt->flags & OF_COMPUTER)) {
            continue;
        }
        if (playmode == PLAYMODE_COMPUTER
         && !in_range(obt->orig->territory_l, obx, obt->orig->territory_r)) {
            continue;
        }
        if (obt->target == NULL
         || iabs(obx - obt->x) < iabs(obt->target->x - obt->x)) {
            obt->target = ob;
        }
    }
}

static bool_t movecomp(obj_t *ob)
{
    compplane = TRUE;
    plyrplane = FALSE;

    ob->flaps = 0;
    ob->flags &= ~(OF_BOMBING | OF_FIRING);
    endstat = ob->endsts;

    switch (ob->state) {
    case FLYING:
    case STALLED:
        if (endstat) {
            gohome(ob);
            break;
        }
        swauto(ob);
        break;

    case CRASHED:
        if (ob->hitcount <= 0 && !endstat) {
            initcomp(ob, ob->orig);
        }
        break;

    default:
        break;
    }

    return movepln(ob);
}

void swmove(void)
{
    obj_t *ob, *obn;
    bool_t drw;

    reapobjs();

    ob = objtop;
    while (ob != NULL) {
        obn = ob->next;

        switch (ob->type) {
        case PLANE:
            drw = (ob->flags & OF_COMPUTER) ? movecomp(ob) : moveplyr(ob);
            if (!(ob->flags & OF_COMPUTER)
             && consoleplayer->endsts == PLAYING
             && !PlaneIsKilled(ob->state)) {
                nearpln(ob);
            }
            break;
        case SHOT:      drw = moveshot(ob); break;
        case BOMB:      drw = movebomb(ob); break;
        case TARGET:    drw = movetarg(ob); break;
        case EXPLOSION: drw = moveexpl(ob); break;
        case SMOKE:     drw = movesmok(ob); break;
        case FLOCK:     drw = moveflck(ob); break;
        case BIRD:      drw = movebird(ob); break;
        case OX:        drw = moveox(ob);   break;
        default:        drw = FALSE;        break;
        }

        if (drw) {
            ob->flags |= OF_DRAW;
        } else {
            ob->flags &= ~OF_DRAW;
        }

        ob = obn;
    }

    countmove++;
}
